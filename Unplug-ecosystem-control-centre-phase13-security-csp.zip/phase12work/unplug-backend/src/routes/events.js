const express = require('express');
const pool = require('../db');
const { logSubmission } = require('./activityLog');
const { requireAuth, requireRole } = require('../middleware/auth');
const { publishesFree, statusForNewSubmission } = require("../utils/publishingRights");
const { getPagination, paginationMeta } = require('../utils/pagination');
const { recordParticipationAsync } = require('../utils/participation');

const router = express.Router();

// GET /events/upcoming — public, approved events from today onward.
// Used directly by the homepage's "Upcoming Events" section.
router.get('/upcoming', async (req, res, next) => {
  try {
    const { page, limit, offset } = getPagination(req);
    // AN EVENT IS OVER WHEN ITS LAST DAY HAS PASSED, not its first.
    //
    // This asked event_date >= CURRENT_DATE, so a festival running Friday to
    // Sunday left the site on Saturday morning, while it was still running and
    // still selling tickets. start_time and end_time did not help: they are
    // times of day, not dates.
    //
    // end_date is NULL for a single-day event, which is every event that existed
    // before it was added, so COALESCE gives exactly the old behaviour for those
    // and the right behaviour for the rest.
    const condition = `status = 'approved' AND COALESCE(end_date, event_date) >= CURRENT_DATE`;

    const countResult = await pool.query(`SELECT COUNT(*) FROM events WHERE ${condition}`);

    const result = await pool.query(
      `SELECT id, name, event_date, end_date, venue, description, image_url, entrance_fee,
              contact_details, event_link,
              to_char(start_time, 'HH24:MI') AS start_time,
              to_char(end_time, 'HH24:MI') AS end_time
       FROM events
       WHERE ${condition}
       ORDER BY event_date ASC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    res.json({
      events: result.rows,
      pagination: paginationMeta(page, limit, parseInt(countResult.rows[0].count, 10)),
    });
  } catch (err) {
    next(err);
  }
});

// POST /events — member submits (enters as 'pending').
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { name, eventDate, endDate, venue, description, displayStartDate,
            imageUrl, entranceFee, contactDetails, eventLink, startTime, endTime } = req.body;
    if (!name || !eventDate) {
      return res.status(400).json({ error: 'name and eventDate are required.' });
    }
    // Refused here as well as by the CHECK, so an organiser gets a sentence
    // rather than a constraint violation.
    if (endDate && String(endDate) < String(eventDate)) {
      return res.status(400).json({ error: 'The end date cannot be before the start date.' });
    }

    const profileResult = await pool.query(
      'SELECT id, free_event_credits FROM profiles WHERE user_id = $1',
      [req.user.id]
    );
    const hasCredit = profileResult.rows.length > 0 && profileResult.rows[0].free_event_credits > 0;

    const result = await pool.query(
      `INSERT INTO events (organizer_user_id, name, event_date, end_date, venue, description, display_start_date,
                           image_url, entrance_fee, contact_details, event_link, start_time, end_time, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
       RETURNING *`,
      [req.user.id, name, eventDate, endDate || null, venue || null, description || null, displayStartDate || null,
       imageUrl || null, entranceFee || null, contactDetails || null, eventLink || null,
       startTime || null, endTime || null, statusForNewSubmission(req.user, hasCredit)]
    );

    if (hasCredit && !publishesFree(req.user)) {
      await pool.query('UPDATE profiles SET free_event_credits = free_event_credits - 1 WHERE id = $1', [profileResult.rows[0].id]);
    }

    recordParticipationAsync(req.user.id, 'content_submit', { contentType: 'event' });

    // Derived from the STATUS that was actually persisted, not re-derived from
    // hasCredit alone — hasCredit only covers the paying-member free-credit
    // case. A consultant has no event credits on their profile (they're staff,
    // not a paying member with a package), so hasCredit is false for them even
    // though statusForNewSubmission() already gave them 'pending' for free.
    // Basing the message on hasCredit alone told a consultant to pay R300 for
    // an event that had already been accepted without payment.
    // Three real outcomes, matching articles.js: admin goes straight to
    // 'approved' and is genuinely live already; a consultant (or a member
    // spending a free credit) reaches 'pending' for a second pair of eyes,
    // still without paying; anyone else owes the listing fee.
    const eventStatus = result.rows[0].status;
    let message;
    if (eventStatus === 'awaiting_payment') {
      message = 'Event created — call POST /payments/initiate with linkedType "event_listing" and this event\'s id (R300.00) to submit it for approval.';
    } else if (eventStatus === 'approved') {
      message = 'Published — this event is live on the calendar now.';
    } else if (publishesFree(req.user)) {
      message = 'Event submitted for approval — no payment needed.';
    } else {
      message = 'Event created using your free Event credit — submitted for approval, no payment needed.';
    }


      // Recorded when it is MADE, not only when an admin acts on it, so the
      // monthly account shows what came in as well as what was decided.
    logSubmission(req.user.id, 'event_submitted', 'Event listing');
    res.status(201).json({ event: result.rows[0], message });
  } catch (err) {
    next(err);
  }
});

// GET /events/admin/all — admin, every event at every status (incl. past),
// for the Calendar Events editor. Newest event date first.
router.get('/admin/all', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, name, event_date, end_date, venue, description, image_url, entrance_fee,
              contact_details, event_link, display_start_date, status,
              to_char(start_time, 'HH24:MI') AS start_time,
              to_char(end_time, 'HH24:MI') AS end_time
         FROM events
        ORDER BY event_date DESC
        LIMIT 300`
    );
    res.json({ events: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /events/:id — admin edits any calendar event. Only the fields sent are
// changed, so editing one field never blanks the rest. A blank string clears
// an optional field.
router.patch('/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid event id is required.' });

    const map = {
      name: 'name', eventDate: 'event_date', endDate: 'end_date', venue: 'venue', description: 'description',
      displayStartDate: 'display_start_date', imageUrl: 'image_url', entranceFee: 'entrance_fee',
      contactDetails: 'contact_details', eventLink: 'event_link',
      startTime: 'start_time', endTime: 'end_time',
    };
    const sets = [];
    const values = [];
    for (const [bodyKey, column] of Object.entries(map)) {
      if (req.body[bodyKey] === undefined) continue;
      let v = req.body[bodyKey];
      if (typeof v === 'string') { v = v.trim(); if (v === '') v = null; }
      // name and event_date can't be cleared — they're required to render.
      if ((column === 'name' || column === 'event_date') && !v) {
        return res.status(400).json({ error: 'Name and date can\'t be blank.' });
      }
      values.push(v);
      sets.push(`${column} = $${values.length}`);
    }
    if (sets.length === 0) return res.status(400).json({ error: 'No fields to update.' });

    values.push(id);
    const result = await pool.query(
      `UPDATE events SET ${sets.join(', ')} WHERE id = $${values.length} RETURNING *`,
      values
    );
    if (result.rowCount === 0) return res.status(404).json({ error: 'Event not found.' });
    res.json({ event: result.rows[0] });
  } catch (err) {
    // A PATCH can set the end date without sending the start date, so whether
    // the two agree depends on the row already in the table. Rather than re-read
    // it and re-implement the rule here — where it could drift from the CHECK —
    // the constraint stays the single authority and its violation is turned
    // into the sentence an admin should see.
    if (err.code === '23514' && err.constraint === 'events_end_date_check') {
      return res.status(400).json({ error: 'The end date cannot be before the start date.' });
    }
    next(err);
  }
});

module.exports = router;
