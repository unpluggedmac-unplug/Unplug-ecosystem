// Admin list / edit / delete, for every reviewable content type.
//
// Until now each type had approve and reject and nothing else: no way to see
// what had already been approved, fix a typo in it, or take it down. That is
// eleven content types, and writing eleven near-identical trios of handlers
// is how they drift apart — one gets a fix, the others don't.
//
// So the resource is a parameter and the behaviour lives in one place. The
// critical part is that the parameter can never reach SQL as text: table and
// column names cannot be parameterised by the driver, so a resource name
// taken from the URL and interpolated into a query is SQL injection with
// extra steps. Everything below is looked up in the hardcoded RESOURCES map
// and an unknown key is a 404 — the request's own strings are never used to
// build SQL.
const express = require('express');
const pool = require('../db');
const { requireRole } = require('../middleware/auth');
const { findPaidPayment, balanceFor, RESOURCE_PAYMENT_TYPES } = require('../utils/accountCredit');
const { isLiveFor } = require('../utils/submissionStatus');
const { referenceFor } = require('../utils/submissionReference');
const { logActivity } = require('./activityLog');

const router = express.Router();

// editable: the only columns an admin may change through this route. Deliberately
//   excludes status (approve/reject own it), ids, foreign keys and created_at —
//   editing is for fixing content, not for rewriting who something belongs to.
// label: the human-readable column, used for confirmation messages.
// joins/extra: read-only context shown in the list.
const RESOURCES = {
  profiles: {
    table: 'profiles',
    label: 'display_name',
    // slug is left out on purpose: it's the public URL, and silently changing
    // it would break every link already shared to that profile.
    editable: ['display_name', 'bio', 'achievements', 'career', 'quote',
               'contact_email', 'contact_phone', 'contact_website'],
  },
  gallery: {
    table: 'gallery_images',
    label: 'caption',
    // title/alt_text/link_url/link_type/display_order/visibility are the admin
    // Gallery Management fields (migration 061) — editable regardless of who
    // originally submitted the image, per spec §27.
    editable: ['caption', 'supplied_by', 'image_url', 'title', 'alt_text',
               'link_url', 'link_type', 'display_order', 'visibility'],
  },
  articles: {
    table: 'articles',
    label: 'title',
    // Includes the feature image (banner_image_url) and the SEO/editorial
    // fields so an already-published article can be fully corrected here, not
    // just its headline and body. Paste an image path/URL to swap the feature
    // image; to upload a brand-new file, the "Write an article" editor's
    // picklist opens the same article with a file-upload control.
    // video_url is editable here as the RAW link; adminContent writes columns
    // directly, so the other three video columns are deliberately NOT in this
    // list — setting an embed url by hand would bypass the parser that is the
    // only thing keeping unchecked addresses out of a frame. To change a video
    // properly, use the article editor, which re-parses the link.
    editable: ['title', 'body', 'kicker_supplied_by', 'banner_image_url',
               'seo_title', 'subtitle', 'meta_description', 'conclusion',
               'cta_label', 'cta_url', 'slug'],
  },
  events: {
    table: 'events',
    label: 'name',
    editable: ['name', 'event_date', 'end_date', 'venue', 'description'],
  },
  investors: {
    table: 'investors',
    label: 'name',
    editable: ['name', 'contact_email'],
  },
  marketplace: {
    table: 'marketplace_listings',
    label: 'headline',
    editable: ['headline', 'poster_image_url', 'active_from', 'active_to',
               'animation_effect', 'transition_duration_ms', 'display_duration_ms'],
    // Same 8-value vocabulary unplug-popups.js already validates for its own
    // entrance-animation dropdown — lets the generic admin editor render a
    // real <select> for this column instead of a free-text box an admin
    // could mistype (see openManageEditor in unplug-admin-dashboard.html).
    selectFields: {
      animation_effect: ['none', 'fade', 'fade-up', 'slide-up', 'slide-down', 'slide-left', 'slide-right', 'zoom'],
    },
  },
  highlights: {
    table: 'highlights',
    label: 'target_type',
    editable: ['start_date', 'end_date'],
  },
  entries: {
    table: 'competition_entries',
    label: 'id',
    editable: [],
  },
  'top10-entries': {
    table: 'top10_entries',
    label: 'id',
    editable: [],
  },
  // The editions calendar has no status column — a save-the-date is either on
  // the calendar or it isn't. It is here for the edit and delete it was
  // missing, and hasStatus keeps the status filter off it.
  edcal: {
    table: 'edition_calendar',
    label: 'title',
    editable: ['event_date', 'title', 'description'],
    hasStatus: false,
  },
};

function resourceFor(req, res) {
  const spec = RESOURCES[req.params.resource];
  if (!spec) {
    res.status(404).json({ error: 'Unknown content type.' });
    return null;
  }
  return spec;
}

function idFor(req, res) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    res.status(400).json({ error: 'A valid id is required.' });
    return null;
  }
  return id;
}

// GET /admin/content/:resource?status=approved
//
// The counterpart to the existing /pending lists: this one can show any
// status, so approved items stop being invisible the moment they're approved.
router.get('/:resource', requireRole('admin'), async (req, res, next) => {
  try {
    const spec = resourceFor(req, res);
    if (!spec) return;

    const params = [];
    const clauses = [];
    const trashRequested = req.query.trash === '1' || req.query.trash === 'true';

    if (trashRequested && spec.hasStatus === false) {
      return res.status(400).json({ error: 'Trash is not available for this legacy content type yet.' });
    }

    if (spec.hasStatus !== false && req.query.status && !trashRequested) {
      // Compared against a fixed set rather than passed through, so an unknown
      // status is a clear 400 instead of a silently empty list.
      const allowed = ['awaiting_payment', 'pending', 'approved', 'rejected', 'draft',
        'changes_requested', 'resubmitted', 'credit_issued', 'expired'];
      if (!allowed.includes(req.query.status)) {
        return res.status(400).json({ error: 'Unknown status filter.' });
      }
      params.push(req.query.status);
      clauses.push(`c.status = $${params.length}`);
    }

    // Active trash is tracked in a compatibility ledger. Normal lists exclude
    // those rows; Trash shows only those rows and includes when/who trashed it.
    let trashJoin = '';
    let selectExtra = '';
    if (spec.hasStatus !== false) {
      if (trashRequested) {
        params.push(req.params.resource);
        trashJoin = ` JOIN admin_content_trash t ON t.item_id = c.id
          AND t.resource = $${params.length}
          AND t.restored_at IS NULL AND t.permanently_deleted_at IS NULL`;
        selectExtra = ', t.previous_status AS _previous_status, t.trashed_at AS _trashed_at, t.trashed_by AS _trashed_by';
      } else {
        params.push(req.params.resource);
        clauses.push(`NOT EXISTS (SELECT 1 FROM admin_content_trash t
          WHERE t.resource = $${params.length} AND t.item_id = c.id
            AND t.restored_at IS NULL AND t.permanently_deleted_at IS NULL)`);
      }
    }

    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const orderColumn = spec.table === 'edition_calendar' ? 'event_date' : 'created_at';
    const result = await pool.query(
      `SELECT c.*${selectExtra} FROM ${spec.table} c${trashJoin} ${where}
       ORDER BY c.${orderColumn} DESC LIMIT 300`,
      params
    );
    res.json({ items: result.rows, editable: spec.editable, selectFields: spec.selectFields || {}, trash: trashRequested, trashSupported: spec.hasStatus !== false });
  } catch (err) {
    next(err);
  }
});

// POST /admin/content/gallery — admin adds a brand-new Gallery image directly
// (owner_type 'general', no owner_id, no payment/bundle). Skips the member
// submission/payment queue entirely, per spec §13.
router.post('/gallery', requireRole('admin'), async (req, res, next) => {
  try {
    const imageUrl = (req.body.imageUrl || '').trim();
    if (!imageUrl) return res.status(400).json({ error: 'An image is required.' });
    const visibility = ['draft', 'published', 'unpublished', 'archived'].includes(req.body.visibility)
      ? req.body.visibility : 'published';
    const linkType = ['external', 'article', 'profile', 'event', 'investor', 'none'].includes(req.body.linkType)
      ? req.body.linkType : null;
    const displayOrder = Number.isInteger(Number(req.body.displayOrder)) ? Number(req.body.displayOrder) : 0;

    const result = await pool.query(
      `INSERT INTO gallery_images
         (owner_type, image_url, title, caption, alt_text, link_url, link_type,
          display_order, visibility, status, updated_at, updated_by)
       VALUES ('general', $1, $2, $3, $4, $5, $6, $7, $8, 'approved', now(), $9)
       RETURNING *`,
      [
        imageUrl,
        (req.body.title || '').trim() || null,
        (req.body.description || req.body.caption || '').trim() || null,
        (req.body.altText || '').trim() || null,
        (req.body.linkUrl || '').trim() || null,
        linkType,
        displayOrder,
        visibility,
        req.user.id,
      ]
    );
    res.status(201).json({ item: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/content/:resource/:id — fix the content of an existing item.
//
// Only the columns in the resource's editable list are touched, and only ones
// actually present in the request, so a partial edit doesn't blank the fields
// it left out.
router.patch('/:resource/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const spec = resourceFor(req, res);
    if (!spec) return;
    const id = idFor(req, res);
    if (id === null) return;

    if (spec.editable.length === 0) {
      return res.status(400).json({ error: 'This content type has nothing that can be edited directly.' });
    }

    // Gallery-specific field validation (visibility / link_type / display_order)
    // — not a DB CHECK constraint, so an invalid value is a clean 400 here
    // rather than either silently accepted or a constraint error.
    if (req.params.resource === 'gallery') {
      if (req.body.visibility !== undefined && req.body.visibility !== '' && req.body.visibility !== null
          && !['draft', 'published', 'unpublished', 'archived'].includes(req.body.visibility)) {
        return res.status(400).json({ error: 'visibility must be draft, published, unpublished or archived.' });
      }
      if (req.body.link_type !== undefined && req.body.link_type !== '' && req.body.link_type !== null
          && !['external', 'article', 'profile', 'event', 'investor', 'none'].includes(req.body.link_type)) {
        return res.status(400).json({ error: 'link_type must be external, article, profile, event, investor or none.' });
      }
      if (req.body.display_order !== undefined && req.body.display_order !== '' && req.body.display_order !== null
          && !Number.isInteger(Number(req.body.display_order))) {
        return res.status(400).json({ error: 'display_order must be a whole number.' });
      }
    }

    // Marketplace-specific field validation (animation_effect / the two _ms
    // duration columns) — not a DB CHECK constraint an admin would ever hit
    // through this generic route in practice (the values come from a real
    // <select>/number input), but validated the same way gallery's fields
    // above are, so a bad value is a clean 400 rather than a raw constraint
    // error surfacing as a 500.
    if (req.params.resource === 'marketplace') {
      const ALLOWED_ANIM = ['none', 'fade', 'fade-up', 'slide-up', 'slide-down', 'slide-left', 'slide-right', 'zoom'];
      if (req.body.animation_effect !== undefined && req.body.animation_effect !== '' && req.body.animation_effect !== null
          && !ALLOWED_ANIM.includes(req.body.animation_effect)) {
        return res.status(400).json({ error: 'animation_effect must be one of: ' + ALLOWED_ANIM.join(', ') });
      }
      for (const f of ['transition_duration_ms', 'display_duration_ms']) {
        if (req.body[f] !== undefined && req.body[f] !== '' && req.body[f] !== null
            && !(Number.isInteger(Number(req.body[f])) && Number(req.body[f]) > 0)) {
          return res.status(400).json({ error: f + ' must be a positive whole number of milliseconds.' });
        }
      }
    }

    const sets = [];
    const values = [];
    spec.editable.forEach((col) => {
      if (!Object.prototype.hasOwnProperty.call(req.body, col)) return;
      let value = req.body[col];
      if (typeof value === 'string') {
        value = value.trim();
        if (value === '') value = null;
      }
      if ((col === 'display_order' || col.endsWith('_ms')) && value !== null) value = Number(value);
      values.push(value);
      sets.push(`${col} = $${values.length}`);
    });

    if (sets.length === 0) {
      return res.status(400).json({ error: 'No editable fields were supplied.' });
    }

    // Stamp who changed a gallery item and when — the table has no updated_at
    // trigger, and this is the only write path that touches gallery content.
    if (req.params.resource === 'gallery') {
      values.push(new Date());
      sets.push(`updated_at = $${values.length}`);
      values.push(req.user.id);
      sets.push(`updated_by = $${values.length}`);
    }

    values.push(id);
    const result = await pool.query(
      `UPDATE ${spec.table} SET ${sets.join(', ')} WHERE id = $${values.length} RETURNING *`,
      values
    );
    if (result.rowCount === 0) return res.status(404).json({ error: 'That item no longer exists.' });
    res.json({ item: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// POST /admin/content/:resource/:id/trash
//
// Reversible delete. The public tables already understand `status = rejected`
// as offline, so we use that existing behaviour and remember the exact prior
// status in admin_content_trash. This avoids a risky site-wide deleted_at
// retrofit while still giving admins WordPress-style Trash / Restore.
router.post('/:resource/:id/trash', requireRole('admin'), async (req, res, next) => {
  const spec = resourceFor(req, res);
  if (!spec) return;
  const id = idFor(req, res);
  if (id === null) return;
  if (spec.hasStatus === false) {
    return res.status(400).json({ error: 'Trash is not available for this legacy content type yet.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const found = await client.query(`SELECT id, status FROM ${spec.table} WHERE id = $1 FOR UPDATE`, [id]);
    if (!found.rowCount) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That item no longer exists.' });
    }
    const active = await client.query(
      `SELECT id FROM admin_content_trash
       WHERE resource = $1 AND item_id = $2
         AND restored_at IS NULL AND permanently_deleted_at IS NULL`,
      [req.params.resource, id]
    );
    if (active.rowCount) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'That item is already in Trash.' });
    }
    const previous = found.rows[0].status;
    await client.query(
      `INSERT INTO admin_content_trash(resource, item_id, previous_status, trashed_by)
       VALUES ($1, $2, $3, $4)`,
      [req.params.resource, id, previous, req.user.id]
    );
    await client.query(`UPDATE ${spec.table} SET status = 'rejected' WHERE id = $1`, [id]);
    await client.query('COMMIT');
    await logActivity(req.user.id, 'content_trashed', `${req.params.resource} #${id}; previous status=${previous}`);
    res.json({ trashed: true, previousStatus: previous });
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    next(err);
  } finally {
    client.release();
  }
});

// POST /admin/content/:resource/:id/restore
router.post('/:resource/:id/restore', requireRole('admin'), async (req, res, next) => {
  const spec = resourceFor(req, res);
  if (!spec) return;
  const id = idFor(req, res);
  if (id === null) return;
  if (spec.hasStatus === false) {
    return res.status(400).json({ error: 'Restore is not available for this legacy content type yet.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const trash = await client.query(
      `SELECT id, previous_status FROM admin_content_trash
       WHERE resource = $1 AND item_id = $2
         AND restored_at IS NULL AND permanently_deleted_at IS NULL
       FOR UPDATE`,
      [req.params.resource, id]
    );
    if (!trash.rowCount) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That item is not in Trash.' });
    }
    const previous = trash.rows[0].previous_status;
    const updated = await client.query(`UPDATE ${spec.table} SET status = $1 WHERE id = $2 RETURNING id`, [previous, id]);
    if (!updated.rowCount) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'The original item no longer exists.' });
    }
    await client.query(
      `UPDATE admin_content_trash SET restored_at = now(), restored_by = $1 WHERE id = $2`,
      [req.user.id, trash.rows[0].id]
    );
    await client.query('COMMIT');
    await logActivity(req.user.id, 'content_restored', `${req.params.resource} #${id}; restored status=${previous}`);
    res.json({ restored: true, status: previous });
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    next(err);
  } finally {
    client.release();
  }
});

// POST /admin/content/:resource/:id/publication
// Generic publish/take-offline control for reviewable content. `approved` is
// the public state used throughout the existing site; `rejected` keeps the
// item offline without deleting it. Trash remains a separate ledger state.
router.post('/:resource/:id/publication', requireRole('admin'), async (req, res, next) => {
  try {
    const spec = resourceFor(req, res);
    if (!spec) return;
    const id = idFor(req, res);
    if (id === null) return;
    if (spec.hasStatus === false) return res.status(400).json({ error: 'This content type has no publication status.' });
    const publish = req.body && req.body.published === true;
    const target = publish ? 'approved' : 'rejected';
    const activeTrash = await pool.query(
      `SELECT 1 FROM admin_content_trash WHERE resource = $1 AND item_id = $2
       AND restored_at IS NULL AND permanently_deleted_at IS NULL`,
      [req.params.resource, id]
    );
    if (activeTrash.rowCount) return res.status(409).json({ error: 'Restore this item from Trash before changing publication.' });
    const result = await pool.query(`UPDATE ${spec.table} SET status = $1 WHERE id = $2 RETURNING *`, [target, id]);
    if (!result.rowCount) return res.status(404).json({ error: 'That item no longer exists.' });
    await logActivity(req.user.id, publish ? 'content_published' : 'content_unpublished', `${req.params.resource} #${id}`);
    res.json({ item: result.rows[0] });
  } catch (err) { next(err); }
});

// DELETE /admin/content/:resource/:id
// Permanent deletion is now permitted only for an item already in Trash.
router.delete('/:resource/:id', requireRole('admin'), async (req, res, next) => {
  const spec = resourceFor(req, res);
  if (!spec) return;
  const id = idFor(req, res);
  if (id === null) return;
  if (spec.hasStatus === false) {
    return res.status(400).json({ error: 'Use the dedicated manager for permanent deletion of this legacy content type.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const trash = await client.query(
      `SELECT id FROM admin_content_trash
       WHERE resource = $1 AND item_id = $2
         AND restored_at IS NULL AND permanently_deleted_at IS NULL FOR UPDATE`,
      [req.params.resource, id]
    );
    if (!trash.rowCount) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Move this item to Trash before deleting it permanently.' });
    }
    const result = await client.query(`DELETE FROM ${spec.table} WHERE id = $1 RETURNING id`, [id]);
    if (!result.rowCount) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That item no longer exists.' });
    }
    await client.query(
      `UPDATE admin_content_trash SET permanently_deleted_at = now(), permanently_deleted_by = $1 WHERE id = $2`,
      [req.user.id, trash.rows[0].id]
    );
    await client.query('COMMIT');
    await logActivity(req.user.id, 'content_permanently_deleted', `${req.params.resource} #${id}`);
    res.json({ deleted: true });
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    next(err);
  } finally { client.release(); }
});

// GET /admin/content/:resource/:id/payment — what would happen if this were
// declined. Lets the dashboard show the real amount on the button instead of
// asking the admin to click and find out.
router.get('/:resource/:id/payment', requireRole('admin'), async (req, res, next) => {
  try {
    const spec = resourceFor(req, res);
    if (!spec) return;
    const id = idFor(req, res);
    if (id === null) return;

    if (!RESOURCE_PAYMENT_TYPES[req.params.resource]) {
      return res.json({ payable: false });
    }
    const payment = await findPaidPayment(req.params.resource, id);
    if (!payment) return res.json({ payable: true, payment: null });

    res.json({
      payable: true,
      payment: {
        id: payment.id,
        amount: Number(payment.amount),
        alreadyCredited: !!payment.credited_at,
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST /admin/content/:resource/:id/decline-with-credit
//
// The decline path from the Refund & Cancellation Policy: reject the
// submission and put what they paid back on their account as credit, in one
// action so the two can't come apart.
//
// Both writes plus the payment flag happen in a single transaction. Rejecting
// the item and then failing to credit would take someone's money for something
// we refused to publish, which is the exact failure this endpoint exists to
// prevent.
router.post('/:resource/:id/decline-with-credit', requireRole('admin'), async (req, res, next) => {
  const spec = resourceFor(req, res);
  if (!spec) return;
  const id = idFor(req, res);
  if (id === null) return;

  if (spec.hasStatus === false) {
    return res.status(400).json({ error: 'This content type is not something that gets approved or paid for.' });
  }
  if (!RESOURCE_PAYMENT_TYPES[req.params.resource]) {
    return res.status(400).json({ error: 'This content type has no paid submissions, so there is nothing to credit.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const payment = await findPaidPayment(req.params.resource, id, client);
    if (!payment) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        error: 'No confirmed payment was found for this submission, so there is nothing to credit. Reject it normally instead.',
      });
    }
    if (payment.credited_at) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        error: 'This payment has already been credited back to the member. Nothing further was done.',
      });
    }

    // WHAT THE CREDIT IS RECORDED AGAINST (spec 10.7).
    //
    // The section asks for the original reference, the original payment, the
    // rejection reason, the amount, the date and the admin. Five of those are
    // already columns on account_credits: payment_id, note, amount,
    // created_at, created_by.
    //
    // The reference is deliberately NOT a sixth column. It lives on the
    // payment, or on the cart order that payment belongs to, and copying it
    // here would be a second copy of the one identifier that must never be
    // ambiguous. It stays reachable through payment_id, and is written into
    // the note as well so an admin reconciling a bank statement can read it
    // without following the link.
    const ref = await referenceFor(payment.linked_type, id, client);
    const givenNote = (req.body.note || '').trim();
    const creditNote = [
      givenNote || `Declined ${req.params.resource} #${id}`,
      ref ? `(reference ${ref.reference})` : null,
    ].filter(Boolean).join(' ');

    // The unique index on payment_id is the real protection against a double
    // credit; this insert is what trips it if two requests race.
    await client.query(
      `INSERT INTO account_credits (user_id, amount, reason, note, payment_id, created_by)
       VALUES ($1, $2, 'declined_submission', $3, $4, $5)`,
      [
        payment.user_id,
        payment.amount,
        creditNote,
        payment.id,
        req.user.id,
      ]
    );

    await client.query('UPDATE payments SET credited_at = now() WHERE id = $1', [payment.id]);

    // A DECLINED-AND-CREDITED SUBMISSION IS NOT SIMPLY 'REJECTED'.
    //
    // Both were written as 'rejected', so nothing could tell a submission
    // that was refused from one that was refused AND paid back. That is the
    // difference between an editorial decision and a money one, and a report
    // that cannot separate them cannot say what has been credited.
    //
    // credit_issued exists only on the services whose migration has landed;
    // writing it elsewhere would violate that table's CHECK. So the
    // vocabulary is asked rather than assumed. Services still waiting for
    // their migration keep the old behaviour and pick this up when they are
    // migrated, with no further change needed here.
    const declinedStatus = isLiveFor('credit_issued', spec.table) ? 'credit_issued' : 'rejected';
    const updated = await client.query(
      `UPDATE ${spec.table} SET status = $1 WHERE id = $2 RETURNING id`,
      [declinedStatus, id]
    );
    if (updated.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That item no longer exists.' });
    }

    await client.query('COMMIT');

    const balance = await balanceFor(payment.user_id);
    res.json({
      declined: true,
      credited: Number(payment.amount),
      userId: payment.user_id,
      newBalance: balance,
      message: `Declined. R${Number(payment.amount).toFixed(2)} was added to their account as credit.`,
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    // The unique index firing means another request credited this payment
    // first. That's the guard working, not a server fault.
    if (err && err.code === '23505') {
      return res.status(409).json({ error: 'This payment has already been credited back to the member.' });
    }
    next(err);
  } finally {
    client.release();
  }
});

module.exports = router;
module.exports.RESOURCES = RESOURCES;