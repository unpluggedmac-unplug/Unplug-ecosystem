const express = require('express');
const pool = require('../db');
const { generateUnique } = require('../utils/reference');
const { requireRole } = require('../middleware/auth');
const { logActivity } = require('./activityLog');
const { balanceFor, historyFor } = require('../utils/accountCredit');
const { sendEmail, isConfigured, verifyConnection, config: emailConfig } = require('../utils/email');
const { marketingStatus } = require('../utils/marketingEvents');
const { probe } = require('../utils/portProbe');
const { getStaffAccess } = require('../utils/staffPermissions');

const router = express.Router();

// Tier + type → free credits granted on approval, per the locked Master Plan.
function creditsForTier(type, tier) {
  if (type === 'individual') {
    if (tier === 'pro') return { article: 1, event: 0, arena: 0, gallery: 1 };
    if (tier === 'premium') return { article: 1, event: 1, arena: 1, gallery: 2 };
  } else if (type === 'business') {
    if (tier === 'pro') return { article: 1, event: 0, arena: 0, gallery: 0 };
    if (tier === 'premium') return { article: 1, event: 1, arena: 0, gallery: 0 };
  }
  return { article: 0, event: 0, arena: 0, gallery: 0 };
}

// GET /admin/users?q=&limit=&offset=
// Admin-only — lists user accounts, paginated. This is a working example of
// how every other /admin/* route from the Backend Spec (Section 3) should be
// wired: requireRole('admin') first, then the actual query.
//
// Search moved server-side (matching email or full_name) rather than the
// dashboard filtering a client-cached full list — that pattern only worked
// because the endpoint used to return every account unconditionally, which
// does not scale as the member base grows.
router.get('/users', requireRole('admin'), async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 200);
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);

    const whereClause = q ? `WHERE u.email ILIKE $1 OR u.full_name ILIKE $1` : '';
    const searchParams = q ? [`%${q}%`] : [];

    // Each account carries a count of the PUBLISHED content it owns. Deleting a
    // user cascades to everything they own, so the admin has to be able to see,
    // before deleting, whether an account is a stray signup or the author of
    // live articles. The count is what the delete guard blocks on too.
    const limitParamIdx = searchParams.length + 1;
    const offsetParamIdx = searchParams.length + 2;
    const result = await pool.query(
      `SELECT u.id, u.email, u.phone, u.role, u.created_at, u.full_name, u.member_type,
              u.is_suspended, u.suspended_reason, u.free_publishing_enabled,
              -- Credit is a SUM of the ledger, not a stored column, so it is
              -- computed here rather than trusted from anywhere else.
              (SELECT COALESCE(SUM(amount), 0) FROM account_credits ac WHERE ac.user_id = u.id)::numeric AS credit_balance,
              (SELECT COUNT(*) FROM articles a WHERE a.author_user_id = u.id AND a.status = 'approved')::int AS published_articles,
              (SELECT COUNT(*) FROM profiles p WHERE p.user_id = u.id AND p.status = 'approved')::int       AS approved_profiles,
              (SELECT COUNT(*) FROM events e WHERE e.organizer_user_id = u.id AND e.status = 'approved')::int AS published_events,
              (SELECT COUNT(*) FROM payments pm WHERE pm.user_id = u.id AND pm.status = 'confirmed')::int    AS confirmed_payments
         FROM users u
         ${whereClause}
        ORDER BY u.created_at DESC
        LIMIT $${limitParamIdx} OFFSET $${offsetParamIdx}`,
      [...searchParams, limit, offset]
    );
    const countResult = await pool.query(`SELECT COUNT(*)::int AS total FROM users u ${whereClause}`, searchParams);

    const access = await getStaffAccess(req.user.id);
    const perms = new Set(access ? access.permissions : []);
    const canFinance = access && (access.isSuperAdmin || perms.has('finance.view') || perms.has('finance.manage'));
    res.json({
      users: result.rows.map((u) => {
        const row = { ...u, credit_balance: Number(u.credit_balance) };
        if (!canFinance) { delete row.credit_balance; delete row.confirmed_payments; }
        return row;
      }),
      total: countResult.rows[0].total, limit, offset,
    });
  } catch (err) {
    next(err);
  }
});

// The roles an account can hold, and the two kinds of member. Kept here rather
// than inline so the API and the CHECK constraint in 046_consultant_role.sql
// can be compared at a glance.
const ASSIGNABLE_ROLES = ['member', 'investor', 'advertiser', 'admin', 'consultant'];
const MEMBER_TYPES = ['individual', 'business'];

// PATCH /admin/users/:id — edit an account's name, phone, role or member type.
//
// Email is deliberately NOT editable. It is the account's identity: it is how
// sign-in works, how magic links are matched, and how guest edition purchases
// are reunited with an account. Changing it here would silently detach a person
// from their own purchase history.
//
// Passwords are not touched either — an admin should never be able to set
// someone's password. Members reset their own.
router.patch('/users/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid user id is required.' });

    const target = await pool.query('SELECT id, email, role FROM users WHERE id = $1', [id]);
    if (target.rowCount === 0) return res.status(404).json({ error: 'That account no longer exists.' });

    const b = req.body;
    if (b.email !== undefined) {
      return res.status(400).json({
        error: "An account's email address can't be changed here — it is how the person signs in and how their purchases are matched to them.",
      });
    }
    if (b.role !== undefined && !ASSIGNABLE_ROLES.includes(b.role)) {
      return res.status(400).json({ error: `Role must be one of: ${ASSIGNABLE_ROLES.join(', ')}.` });
    }
    if (b.role !== undefined && b.role !== target.rows[0].role && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Only a Super Admin can change account roles.' });
    }
    if (b.memberType !== undefined && b.memberType !== null && b.memberType !== ''
        && !MEMBER_TYPES.includes(b.memberType)) {
      return res.status(400).json({ error: `Member type must be ${MEMBER_TYPES.join(' or ')}.` });
    }

    // Changing your own role is how an admin locks themselves out of the
    // dashboard they are standing in. Another admin can do it; you can't do it
    // to yourself.
    if (b.role !== undefined && id === req.user.id && b.role !== target.rows[0].role) {
      return res.status(400).json({
        error: 'You cannot change your own role — that would lock you out of the admin dashboard.',
      });
    }

    // Same self-lockout protection for suspension — an admin suspending
    // their own account would need a second admin to undo it.
    if (b.isSuspended !== undefined && id === req.user.id) {
      return res.status(400).json({ error: 'You cannot suspend the account you are signed in with.' });
    }

    // Sales/consultant access is deliberately a ROLE (granted here, revocable
    // later) rather than a live email-domain check on every request — see the
    // comment in 046_consultant_role.sql for why: a pure domain check would
    // mean anyone who ever signed up with a company address keeps free
    // publishing forever, even after leaving, since there'd be no role to take
    // away. The domain restriction the brief asks for is enforced at the one
    // moment it actually matters — the grant itself.
    if (b.role === 'consultant' && !/@unplugnews\.com$/i.test(target.rows[0].email)) {
      return res.status(400).json({
        error: 'Only an @unplugnews.com email address can be made a Sales Consultant. This account is ' + target.rows[0].email + '.',
      });
    }

    const sets = [];
    const vals = [];
    const put = (col, val) => { vals.push(val); sets.push(`${col} = $${vals.length}`); };
    if (b.fullName !== undefined) put('full_name', String(b.fullName).trim().slice(0, 160) || null);
    if (b.phone !== undefined) put('phone', String(b.phone).trim().slice(0, 40) || null);
    if (b.role !== undefined) put('role', b.role);
    if (b.memberType !== undefined) put('member_type', b.memberType || null);
    if (b.isSuspended !== undefined) put('is_suspended', !!b.isSuspended);
    if (b.suspendedReason !== undefined) put('suspended_reason', String(b.suspendedReason).trim().slice(0, 300) || null);
    // Only meaningful for role 'consultant' (see publishingRights.js) — stored
    // and accepted unconditionally anyway, same as every other column here,
    // since it does nothing for any other role.
    if (b.freePublishingEnabled !== undefined) put('free_publishing_enabled', !!b.freePublishingEnabled);
    if (sets.length === 0) return res.status(400).json({ error: 'Nothing to update.' });

    vals.push(id);
    const result = await pool.query(
      `UPDATE users SET ${sets.join(', ')} WHERE id = $${vals.length}
       RETURNING id, email, phone, role, full_name, member_type, is_suspended, suspended_reason, free_publishing_enabled`,
      vals
    );

    // Granting or removing admin is the change most worth being able to trace
    // later, so it is called out rather than folded into a generic message.
    // Same reasoning for the free-publishing toggle — it is real money
    // (or the deliberate lack of it), so it gets its own trail too.
    const roleChanged = b.role !== undefined && b.role !== target.rows[0].role;
    logActivity(
      req.user.id,
      roleChanged ? 'user_role_changed'
        : b.isSuspended !== undefined ? (b.isSuspended ? 'user_suspended' : 'user_unsuspended')
        : b.freePublishingEnabled !== undefined ? 'user_free_publishing_toggled'
        : 'user_edited',
      roleChanged
        ? `${target.rows[0].email} (#${id}): ${target.rows[0].role} → ${b.role}`
        : b.freePublishingEnabled !== undefined
        ? `${target.rows[0].email} (#${id}): free publishing ${b.freePublishingEnabled ? 'enabled' : 'disabled'}`
        : `${target.rows[0].email} (#${id})`
    );

    res.json({ user: result.rows[0], message: 'Account updated.' });
  } catch (err) {
    next(err);
  }
});

// GET /admin/users/:id/credits — an account's credit balance and every entry
// behind it, so an admin can answer "why does this person have R150?".
router.get('/users/:id/credits', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid user id is required.' });
    const [balance, history] = await Promise.all([balanceFor(id), historyFor(id)]);
    res.json({ balance, history });
  } catch (err) {
    next(err);
  }
});

// POST /admin/users/:id/credits — manually add or remove account credit.
//
// This is real money the customer can spend at checkout, so: a note is
// required (a credit with no stated reason is unauditable), the balance can
// never be pushed below zero, and the whole thing runs in a transaction with
// the balance read FOR UPDATE — two admins adjusting at once would otherwise
// both read the old balance and both succeed.
router.post('/users/:id/credits', requireRole('admin'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid user id is required.' });

    const amount = Number(req.body.amount);
    if (!Number.isFinite(amount) || amount === 0) {
      return res.status(400).json({ error: 'Enter an amount — positive to add credit, negative to take it away.' });
    }
    const note = String(req.body.note || '').trim();
    if (!note) {
      return res.status(400).json({ error: 'Add a note saying why — account credit should never be unexplained.' });
    }

    await client.query('BEGIN');
    const target = await client.query('SELECT id, email FROM users WHERE id = $1 FOR UPDATE', [id]);
    if (target.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That account no longer exists.' });
    }

    const current = await balanceFor(id, client);
    const next = current + amount;
    if (next < 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        error: `That would take the balance to R${next.toFixed(2)}. This account only has R${current.toFixed(2)} of credit.`,
      });
    }

    await client.query(
      `INSERT INTO account_credits (user_id, amount, reason, note, created_by)
       VALUES ($1, $2, 'admin_adjustment', $3, $4)`,
      [id, amount, note.slice(0, 500), req.user.id]
    );
    await client.query('COMMIT');

    logActivity(req.user.id, 'credit_adjusted',
      `${target.rows[0].email} (#${id}): ${amount > 0 ? '+' : ''}R${amount.toFixed(2)} — ${note.slice(0, 120)}`);

    res.json({
      balance: next,
      message: `${amount > 0 ? 'Added' : 'Removed'} R${Math.abs(amount).toFixed(2)}. New balance: R${next.toFixed(2)}.`,
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    next(err);
  } finally {
    client.release();
  }
});

// DELETE /admin/users/:id — remove an account.
//
// Guarded on purpose. Deleting a user cascades to everything they own —
// articles, profiles, events, payment history — so this refuses to delete an
// account that owns anything PUBLISHED or any confirmed payment. That is the
// "keep content-owning accounts" rule made mechanical: a member who authored
// live articles can't be wiped by a mis-click; their content would have to be
// reassigned first. Stray signups with nothing published delete cleanly.
router.delete('/users/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid user id is required.' });

    // Never let an admin delete the account they're signed in with — that's
    // always a mistake, and it would lock them out mid-action.
    if (id === req.user.id) {
      return res.status(400).json({ error: 'You cannot delete the account you are signed in with.' });
    }

    const target = await pool.query('SELECT id, email, role FROM users WHERE id = $1', [id]);
    if (target.rowCount === 0) return res.status(404).json({ error: 'That account no longer exists.' });

    // Other admins aren't deletable through this tool — losing an admin should
    // be a deliberate act, not a row in a members cleanup.
    if (['admin', 'staff'].includes(target.rows[0].role)) {
      return res.status(403).json({ error: 'Admin and staff accounts cannot be deleted here. Remove staff access or change the role first.' });
    }

    const owned = await pool.query(
      `SELECT
         (SELECT COUNT(*) FROM articles WHERE author_user_id = $1 AND status = 'approved')::int AS articles,
         (SELECT COUNT(*) FROM profiles WHERE user_id = $1 AND status = 'approved')::int         AS profiles,
         (SELECT COUNT(*) FROM events WHERE organizer_user_id = $1 AND status = 'approved')::int  AS events,
         (SELECT COUNT(*) FROM payments WHERE user_id = $1 AND status = 'confirmed')::int         AS payments`,
      [id]
    );
    const o = owned.rows[0];
    const blockers = [];
    if (o.articles) blockers.push(`${o.articles} published article${o.articles > 1 ? 's' : ''}`);
    if (o.profiles) blockers.push(`${o.profiles} approved profile${o.profiles > 1 ? 's' : ''}`);
    if (o.events) blockers.push(`${o.events} published event${o.events > 1 ? 's' : ''}`);
    if (o.payments) blockers.push(`${o.payments} confirmed payment${o.payments > 1 ? 's' : ''}`);
    if (blockers.length > 0) {
      return res.status(409).json({
        error: `This account owns ${blockers.join(', ')}. Deleting it would remove that content too. Reassign or remove the content first, then delete the account.`,
      });
    }

    await pool.query('DELETE FROM users WHERE id = $1', [id]);
    logActivity(req.user.id, 'user_deleted', `${target.rows[0].email} (#${id})`);
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
});

// GET /admin/vouchers — admin-only. Lists every voucher ever created.
router.get('/vouchers', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT v.*, u.email AS created_by_email,
              (SELECT COUNT(*) FROM voucher_redemptions r WHERE r.voucher_id = v.id) AS times_redeemed
       FROM vouchers v
       LEFT JOIN users u ON u.id = v.created_by
       ORDER BY v.created_at DESC`
    );
    res.json({ vouchers: result.rows });
  } catch (err) {
    next(err);
  }
});

// POST /admin/vouchers — admin-only. Creates a new voucher code.
// discount_type: 'percent' or 'fixed'. expires_at is mandatory.
// service_restriction is optional — omit or leave blank for "any service".
router.post('/vouchers', requireRole('admin'), async (req, res, next) => {
  try {
    const { code, discountType, discountValue, serviceRestriction, expiresAt } = req.body;
    if (!discountType || !discountValue || !expiresAt) {
      return res.status(400).json({ error: 'discountType, discountValue and expiresAt are all required.' });
    }
    // Codes are generated unless one is supplied. Hand-typed codes tend to
    // collide or get guessed; these are random and skip characters that are
    // easy to misread aloud or in print (0/O, 1/I).
    let finalCode = (code || '').toUpperCase().trim();
    if (!finalCode) {
      // Was Math.random(); now crypto, via the shared generator. A discount
      // code is exactly the thing that should not be guessable from a seed.
      // Same shape as before: UNP- and six characters.
      try {
        finalCode = await generateUnique({
          table: 'vouchers', column: 'code', prefix: 'UNP-', length: 6,
        });
      } catch (e) {
        return res.status(500).json({ error: 'Could not generate a unique voucher code. Please try again.' });
      }
    }
    if (!['percent', 'fixed'].includes(discountType)) {
      return res.status(400).json({ error: 'discountType must be "percent" or "fixed".' });
    }
    const result = await pool.query(
      `INSERT INTO vouchers (code, discount_type, discount_value, service_restriction, expires_at, created_by)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [finalCode, discountType, discountValue, serviceRestriction || null, expiresAt, req.user.id]
    );
    await logActivity(req.user.id, 'voucher_created', `Voucher ${result.rows[0].code} — ${discountType} ${discountValue}`);
    res.status(201).json({ voucher: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(400).json({ error: 'That voucher code already exists.' });
    }
    next(err);
  }
});

// PATCH /admin/vouchers/:id/deactivate — admin-only. Turns a voucher off
// without deleting its redemption history.
router.patch('/vouchers/:id/deactivate', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE vouchers SET active = false WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Voucher not found.' });
    }
    await logActivity(req.user.id, 'voucher_deactivated', `Voucher ${result.rows[0].code}`);
    res.json({ voucher: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/profiles/pending
// Admin-only — the Directory tab of the Approval Queue.
router.get('/profiles/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT p.id, p.display_name, p.package_tier, p.status, p.created_at, c.name AS category, u.email AS submitted_by
       FROM profiles p
       LEFT JOIN categories c ON c.id = p.category_id
       JOIN users u ON u.id = p.user_id
       WHERE p.status = 'pending'
       ORDER BY p.created_at ASC`
    );
    res.json({ profiles: result.rows });
  } catch (err) {
    next(err);
  }
});

// GET /admin/profiles/renewals-due — admin-only. Lists approved profiles
// whose renews_at falls within the next 30 days, or has already passed.
router.get('/profiles/renewals-due', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT p.id, p.display_name, p.type, p.package_tier, p.renews_at, u.email AS contact_email
       FROM profiles p
       JOIN users u ON u.id = p.user_id
       WHERE p.status = 'approved' AND p.renews_at IS NOT NULL AND p.renews_at <= now() + interval '30 days'
       ORDER BY p.renews_at ASC`
    );
    res.json({ profiles: result.rows });
  } catch (err) {
    next(err);
  }
});

// GET /admin/profiles/approved
// Admin-only — lists all approved Directory profiles, with verification
// and credit-renewal status, so there's somewhere to use the Verify and
// Renew actions after a profile has already been approved.
router.get('/profiles/approved', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT p.id, p.display_name, p.type, p.package_tier, p.verified, p.deaf_owned_verified, p.is_featured, p.renews_at, p.feature_image_url, c.name AS category, u.email AS submitted_by
       FROM profiles p
       LEFT JOIN categories c ON c.id = p.category_id
       JOIN users u ON u.id = p.user_id
       WHERE p.status = 'approved'
       ORDER BY p.display_name ASC`
    );
    res.json({ profiles: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/profiles/:id/approve
router.patch('/profiles/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE profiles SET status = 'approved', updated_at = now() WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }
    const profile = result.rows[0];
    const credits = creditsForTier(profile.type, profile.package_tier);
    const credited = await pool.query(
      `UPDATE profiles SET free_article_credits = $1, free_event_credits = $2, free_arena_credits = $3,
              free_gallery_credits = $4, credits_renewed_at = now(), renews_at = now() + interval '1 year'
       WHERE id = $5 RETURNING *`,
      [credits.article, credits.event, credits.arena, credits.gallery, profile.id]
    );
    await logActivity(req.user.id, 'profile_approved', `Profile #${req.params.id} — ${profile.display_name}`);
    // No-op for non-business profiles — see check_and_update_business_status().
    pool.query('SELECT check_and_update_business_status($1)', [profile.id]).catch(() => {});
    res.json({ profile: credited.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/profiles/:id/verify — admin confirms the ID document or
// business registration number checked outside this system, then flips
// the Verified badge on. `note` is a free-text reference (e.g. document
// type or registration number), not the document itself.
router.patch('/profiles/:id/verify', requireRole('admin'), async (req, res, next) => {
  try {
    const { note } = req.body;
    const result = await pool.query(
      `UPDATE profiles SET verified = true, verification_note = $1, updated_at = now() WHERE id = $2 RETURNING *`,
      [note || null, req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }
    await logActivity(req.user.id, 'profile_verified', `Profile #${req.params.id} — ${result.rows[0].display_name}`);
    res.json({ profile: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/profiles/:id/deaf-owned — toggles the Deaf-Owned Verified
// badge on a profile. Flipping (not just setting true) lets one button in
// the admin queue both grant and remove the badge.
router.patch('/profiles/:id/deaf-owned', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE profiles SET deaf_owned_verified = NOT deaf_owned_verified, updated_at = now()
       WHERE id = $1 RETURNING id, display_name, deaf_owned_verified`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }
    await logActivity(req.user.id, 'profile_deaf_owned_toggled',
      `Profile #${req.params.id} — ${result.rows[0].display_name} → deaf-owned ${result.rows[0].deaf_owned_verified}`);
    res.json({ profile: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/profiles/:id/feature — Members/Community System Phase 8:
// toggles a listing's is_featured flag, which controls whether it shows
// up under the Members page's "Featured" sort (Phase 5). Same
// toggle-not-set pattern as /deaf-owned above.
router.patch('/profiles/:id/feature', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE profiles SET is_featured = NOT is_featured, updated_at = now()
       WHERE id = $1 RETURNING id, display_name, is_featured`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }
    await logActivity(req.user.id, 'profile_featured_toggled',
      `Profile #${req.params.id} — ${result.rows[0].display_name} → featured ${result.rows[0].is_featured}`);
    res.json({ profile: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

function profileSlugify(name) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

// POST /admin/profiles — admin creates a Directory listing directly, for a
// sponsor/business/person who has no member account (and may never get one)
// — e.g. captured at an event, or a partner the site wants listed before
// they sign up. Requested directly: "allow admin to add directory profiles
// manually."
//
// Deliberately different from POST /profiles (the member's own submission
// route) in two ways: no user_id at all (177_admin_created_profiles.sql made
// that column nullable for exactly this), and status is 'approved' on the
// spot — an admin publishing their own curated listing needs no approval
// queue and no payment, the same free-and-instant treatment every other
// admin-authored submission gets on this site.
//
// The requirement set matches exactly what a member fills in at their own
// "Choose Your Directory Package" checkout step (unplug-checkout.html):
// second category only for a business on Premium, a demo reel link only for
// an individual on Premium, location entirely optional with a street address
// only for a business. Everything else about the listing — bio, achievements,
// contact details, feature image — is filled in afterward through the SAME
// editor every other listing uses (PATCH /profiles/:id). If it should later
// belong to a real member, the existing "Link a listing to a member
// account" panel (adminProfileLinks.js) does that without recreating
// anything.
router.post('/profiles', requireRole('admin'), async (req, res, next) => {
  try {
    const { type, categoryId, secondaryCategoryId, packageTier, displayName, demoReelUrl,
            streetAddress, suburb, city, province, country } = req.body;
    if (!displayName || !displayName.trim()) {
      return res.status(400).json({ error: 'displayName is required.' });
    }
    const PACKAGE_TIERS = ['basic', 'pro', 'premium'];
    if (!PACKAGE_TIERS.includes(packageTier)) {
      return res.status(400).json({ error: `packageTier must be one of: ${PACKAGE_TIERS.join(', ')}` });
    }
    const profileType = type === 'business' ? 'business' : 'individual';
    const isBusiness = profileType === 'business';
    const allowSecondCategory = isBusiness && packageTier === 'premium';
    const allowDemoReel = !isBusiness && packageTier === 'premium';

    let slug = profileSlugify(displayName);
    const slugTaken = await pool.query('SELECT id FROM profiles WHERE slug = $1', [slug]);
    if (slugTaken.rows.length > 0) {
      slug = `${slug}-${Date.now().toString(36)}`;
    }

    const result = await pool.query(
      `INSERT INTO profiles
        (user_id, type, category_id, secondary_category_id, package_tier, slug, display_name, status,
         demo_reel_url, street_address, suburb, city, province, country)
       VALUES (NULL, $1, $2, $3, $4, $5, $6, 'approved', $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [profileType, categoryId || null, allowSecondCategory ? (secondaryCategoryId || null) : null,
       packageTier, slug, displayName.trim(),
       allowDemoReel ? ((demoReelUrl || '').trim() || null) : null,
       isBusiness ? ((streetAddress || '').trim() || null) : null,
       (suburb || '').trim() || null, (city || '').trim() || null,
       (province || '').trim() || null, (country || '').trim() || null]
    );

    await logActivity(req.user.id, 'directory_listing_created_by_admin',
      `Created the Directory listing "${result.rows[0].display_name}" (#${result.rows[0].id}), live immediately with no owner`).catch(() => {});

    res.status(201).json({
      profile: result.rows[0],
      message: 'Listing created and live. Add its bio, contact details and feature image below, or link it to a member account from the Profile Linking panel.',
    });
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/profiles/:id — permanently removes a Directory listing an
// admin manages directly. Every FK from other tables (competition entries,
// top10 archive, CRM, article backlinks…) already cascades or SETs NULL on
// its own; social_links and gallery_images are polymorphic (owner_type/
// owner_id, no real FK) so they are cleaned up here explicitly, or they
// would be silently orphaned rows nothing ever reads again.
router.delete('/profiles/:id', requireRole('admin'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid profile id is required.' });

    await client.query('BEGIN');
    const profile = await client.query('SELECT display_name FROM profiles WHERE id = $1 FOR UPDATE', [id]);
    if (profile.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That listing no longer exists.' });
    }
    await client.query(`DELETE FROM social_links WHERE owner_type = 'profile' AND owner_id = $1`, [id]);
    await client.query(`DELETE FROM gallery_images WHERE owner_type = 'profile' AND owner_id = $1`, [id]);
    await client.query('DELETE FROM profiles WHERE id = $1', [id]);
    await client.query('COMMIT');

    await logActivity(req.user.id, 'directory_listing_deleted',
      `Deleted the Directory listing "${profile.rows[0].display_name}" (#${id})`).catch(() => {});
    res.json({ deleted: true, message: `"${profile.rows[0].display_name}" has been permanently removed.` });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    next(err);
  } finally {
    client.release();
  }
});

// GET /admin/profiles/all — every Directory profile, for the per-profile
// editor's picker. All statuses, newest first.
router.get('/profiles/all', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT p.id, p.display_name, p.slug, p.status, p.package_tier,
              c.name AS category
         FROM profiles p
         LEFT JOIN categories c ON c.id = p.category_id
        ORDER BY p.display_name ASC
        LIMIT 500`
    );
    res.json({ profiles: result.rows });
  } catch (err) {
    next(err);
  }
});

// GET /admin/profiles/:id/gallery — a profile's gallery images, any status.
router.get('/profiles/:id/gallery', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid profile id is required.' });
    const result = await pool.query(
      `SELECT id, image_url, caption, status
         FROM gallery_images
        WHERE owner_type = 'profile' AND owner_id = $1
        ORDER BY created_at DESC`,
      [id]
    );
    res.json({ gallery: result.rows });
  } catch (err) {
    next(err);
  }
});

// POST /admin/profiles/:id/gallery — admin adds a gallery image to any
// profile, approved on the spot (no member-facing credit/payment path).
router.post('/profiles/:id/gallery', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid profile id is required.' });
    const imageUrl = (req.body.imageUrl || '').trim();
    if (!imageUrl) return res.status(400).json({ error: 'An image is required.' });
    const profile = await pool.query('SELECT id FROM profiles WHERE id = $1', [id]);
    if (profile.rowCount === 0) return res.status(404).json({ error: 'That profile no longer exists.' });

    const result = await pool.query(
      `INSERT INTO gallery_images (owner_type, owner_id, image_url, caption, status)
       VALUES ('profile', $1, $2, $3, 'approved')
       RETURNING id, image_url, caption, status`,
      [id, imageUrl, (req.body.caption || '').trim() || null]
    );
    logActivity(req.user.id, 'profile_gallery_added', `Profile #${id}`);
    res.status(201).json({ image: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/profiles/gallery/:imageId — remove one gallery image.
router.delete('/profiles/gallery/:imageId', requireRole('admin'), async (req, res, next) => {
  try {
    const imageId = Number(req.params.imageId);
    if (!Number.isInteger(imageId)) return res.status(400).json({ error: 'A valid image id is required.' });
    const result = await pool.query(
      `DELETE FROM gallery_images WHERE id = $1 AND owner_type = 'profile' RETURNING id`,
      [imageId]
    );
    if (result.rowCount === 0) return res.status(404).json({ error: 'That image no longer exists.' });
    logActivity(req.user.id, 'profile_gallery_removed', `image #${imageId}`);
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/profiles/:id/renew — call this once a year (manually, for
// now) to refresh a profile's included credits and push its renewal date
// out another year. No downgrade path exists, so this always re-grants
// whatever the profile's CURRENT tier includes.
router.patch('/profiles/:id/renew', requireRole('admin'), async (req, res, next) => {
  try {
    const profileResult = await pool.query('SELECT * FROM profiles WHERE id = $1', [req.params.id]);
    if (profileResult.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }
    const profile = profileResult.rows[0];
    const credits = creditsForTier(profile.type, profile.package_tier);
    const result = await pool.query(
      `UPDATE profiles SET free_article_credits = $1, free_event_credits = $2, free_arena_credits = $3,
              free_gallery_credits = $4, renews_at = now() + interval '1 year', updated_at = now()
       WHERE id = $5 RETURNING *`,
      [credits.article, credits.event, credits.arena, credits.gallery, req.params.id]
    );
    await logActivity(req.user.id, 'profile_renewed', `Profile #${req.params.id} — ${profile.display_name} — credits refreshed for another year`);
    res.json({ profile: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/profiles/:id/reject
router.patch('/profiles/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE profiles SET status = 'rejected', updated_at = now() WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Profile not found.' });
    }
    await logActivity(req.user.id, 'profile_rejected', `Profile #${req.params.id} — ${result.rows[0].display_name}`);
    res.json({ profile: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/gallery/pending
// Admin-only — the Gallery tab of the Approval Queue (covers profile,
// investor, and general gallery submissions in one list).
router.get('/gallery/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, owner_type, owner_id, image_url, caption, supplied_by, created_at
       FROM gallery_images
       WHERE status = 'pending'
       ORDER BY created_at ASC`
    );
    res.json({ images: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/gallery/:id/approve
router.patch('/gallery/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE gallery_images SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Image not found.' });
    }
    const image = result.rows[0];
    if (image.owner_type === 'profile') {
      pool.query('SELECT check_and_update_business_status($1)', [image.owner_id]).catch(() => {});
    }
    res.json({ image });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/gallery/:id/reject
router.patch('/gallery/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE gallery_images SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Image not found.' });
    }
    res.json({ image: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/articles/pending — the Latest News tab of the Approval Queue.
router.get('/articles/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT a.id, a.title, a.kicker_supplied_by, a.created_at, c.name AS category, u.email AS submitted_by
       FROM articles a
       LEFT JOIN categories c ON c.id = a.category_id
       JOIN users u ON u.id = a.author_user_id
       WHERE a.status = 'pending'
       ORDER BY a.created_at ASC`
    );
    res.json({ articles: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/articles/:id/approve — sets published_at so it appears in the
// public /articles feed. An optional scheduledFor date holds it back until
// that day: the feed only shows approved articles whose scheduled_for is null
// or already past, so a future date publishes on its own with no cron.
router.patch('/articles/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const scheduledFor = req.body.scheduledFor || null;
    const result = await pool.query(
      `UPDATE articles
          SET status = 'approved',
              published_at = COALESCE(published_at, now()),
              scheduled_for = $2
        WHERE id = $1
        RETURNING *`,
      [req.params.id, scheduledFor]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    await logActivity(req.user.id, 'article_approved',
      `Article #${req.params.id} — ${result.rows[0].title}${scheduledFor ? ` (scheduled ${scheduledFor})` : ''}`);
    res.json({ article: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/articles/:id/reject
router.patch('/articles/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE articles SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    await logActivity(req.user.id, 'article_rejected', `Article #${req.params.id} — ${result.rows[0].title}`);
    res.json({ article: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/events/pending — the Events tab of the Approval Queue.
router.get('/events/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT e.id, e.name, e.event_date, e.venue, e.created_at, u.email AS organizer
       FROM events e
       JOIN users u ON u.id = e.organizer_user_id
       WHERE e.status = 'pending'
       ORDER BY e.event_date ASC`
    );
    res.json({ events: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/events/:id/approve
router.patch('/events/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE events SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Event not found.' });
    }
    res.json({ event: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/events/:id/reject
router.patch('/events/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE events SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Event not found.' });
    }
    res.json({ event: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/entries/pending — the Competitions tab of the Approval Queue.
// Only shows entries that have already been paid for (status 'pending') —
// entries still 'awaiting_payment' aren't an admin's problem yet.
router.get('/entries/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT ce.id, ce.competition_id, ce.entry_fee, ce.created_at, p.display_name, c.name AS competition_name
       FROM competition_entries ce
       JOIN profiles p ON p.id = ce.profile_id
       JOIN competitions c ON c.id = ce.competition_id
       WHERE ce.status = 'pending'
       ORDER BY ce.created_at ASC`
    );
    res.json({ entries: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/entries/:id/approve
router.patch('/entries/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE competition_entries SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Entry not found.' });
    }
    res.json({ entry: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/entries/:id/reject
router.patch('/entries/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE competition_entries SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Entry not found.' });
    }
    res.json({ entry: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/investors/pending — the Investors tab of the Approval Queue.
router.get('/investors/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT i.id, i.name, i.contact_email, i.created_at, u.email AS submitted_by
       FROM investors i
       JOIN users u ON u.id = i.user_id
       WHERE i.status = 'pending'
       ORDER BY i.created_at ASC`
    );
    res.json({ investors: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/investors/:id/approve
router.patch('/investors/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE investors SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Investor not found.' });
    }
    res.json({ investor: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/investors/:id/reject
router.patch('/investors/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE investors SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Investor not found.' });
    }
    res.json({ investor: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/marketplace/pending — the Marketplace tab of the Approval
// Queue (banners and ads submitted by advertisers).
router.get('/marketplace/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT l.id, l.headline, l.duration_days, l.created_at, a.business_name
       FROM marketplace_listings l
       JOIN advertisers a ON a.id = l.advertiser_id
       WHERE l.status = 'pending'
       ORDER BY l.created_at ASC`
    );
    res.json({ listings: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/marketplace/:id/approve
router.patch('/marketplace/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE marketplace_listings SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found.' });
    }
    res.json({ listing: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/marketplace/:id/reject
router.patch('/marketplace/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE marketplace_listings SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Listing not found.' });
    }
    res.json({ listing: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/highlights/pending — the Highlights & Promotions tab.
router.get('/highlights/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, target_type, target_id, duration_days, created_at
       FROM highlights
       WHERE status = 'pending'
       ORDER BY created_at ASC`
    );
    res.json({ highlights: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/highlights/:id/approve
router.patch('/highlights/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE highlights SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Highlight not found.' });
    }
    res.json({ highlight: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/highlights/:id/reject
router.patch('/highlights/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE highlights SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Highlight not found.' });
    }
    res.json({ highlight: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/sales-consultants — full list (active + inactive).
router.get('/sales-consultants', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(`SELECT * FROM sales_consultants ORDER BY name ASC`);
    res.json({ consultants: result.rows });
  } catch (err) {
    next(err);
  }
});

// POST /admin/sales-consultants — add a new consultant.
router.post('/sales-consultants', requireRole('admin'), async (req, res, next) => {
  try {
    const { name, email, commissionPct } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'name is required.' });
    }
    const result = await pool.query(
      `INSERT INTO sales_consultants (name, email, commission_pct)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [name.trim(), email || null, commissionPct != null ? commissionPct : 10.00]
    );
    res.status(201).json({ consultant: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/sales-consultants/:id — edit name/email/commission/active.
router.patch('/sales-consultants/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const bodyKeyMap = { name: 'name', email: 'email', commissionPct: 'commission_pct', active: 'active' };
    const setClauses = [];
    const values = [];
    for (const [bodyKey, column] of Object.entries(bodyKeyMap)) {
      if (req.body[bodyKey] !== undefined) {
        values.push(req.body[bodyKey]);
        setClauses.push(`${column} = $${values.length}`);
      }
    }
    if (setClauses.length === 0) {
      return res.status(400).json({ error: 'No editable fields provided.' });
    }
    values.push(req.params.id);

    const result = await pool.query(
      `UPDATE sales_consultants SET ${setClauses.join(', ')} WHERE id = $${values.length} RETURNING *`,
      values
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Consultant not found.' });
    }
    res.json({ consultant: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/sales-consultants/:id/payments — every confirmed payment
// attributed to this consultant, for commission calculation. The
// commission amount is computed here (amount × commission_pct) rather
// than stored on each payment, so changing a consultant's rate later
// doesn't require rewriting historical records.
router.get('/sales-consultants/:id/payments', requireRole('admin'), async (req, res, next) => {
  try {
    const consultantResult = await pool.query('SELECT * FROM sales_consultants WHERE id = $1', [req.params.id]);
    if (consultantResult.rows.length === 0) {
      return res.status(404).json({ error: 'Consultant not found.' });
    }
    const consultant = consultantResult.rows[0];

    const payments = await pool.query(
      `SELECT id, amount, method, linked_type, linked_id, status, confirmed_at, created_at
       FROM payments
       WHERE sales_consultant_id = $1 AND status = 'confirmed'
       ORDER BY confirmed_at DESC`,
      [req.params.id]
    );

    const totalSales = payments.rows.reduce((sum, p) => sum + Number(p.amount), 0);
    const totalCommission = totalSales * (Number(consultant.commission_pct) / 100);

    res.json({
      consultant,
      payments: payments.rows,
      totalSales,
      totalCommission: Math.round(totalCommission * 100) / 100,
    });
  } catch (err) {
    next(err);
  }
});

// GET /admin/notifications — unread-first feed. A sales-consultant-linked
// payment automatically creates one of these (see payments.js) so the
// admin doesn't have to go hunting through the full payments table.
// GET /admin/overview — the Dashboard Overview landing screen: enough of the
// platform's current state to answer "what needs my attention today?" in one
// call, rather than opening ten sections to find out.
//
// Every count here reads a table that already exists and is already the
// source of truth for its own admin section — this endpoint does not
// duplicate any business logic, it only aggregates.
router.get('/overview', requireRole('admin'), async (req, res, next) => {
  try {
    const access = await getStaffAccess(req.user.id);
    const perms = new Set(access ? access.permissions : []);
    const can = (...needed) => access && (access.isSuperAdmin || needed.some((p) => perms.has(p)));
    const [
      users, articles, profiles, editions, gallery,
      pendingEft, pendingArticles, pendingProfiles, pendingGallery,
      pendingClaims, pendingReviews, pendingComments,
      views7d, unreadNotifications,
    ] = await Promise.all([
      pool.query(`SELECT COUNT(*)::int AS n FROM users`),
      pool.query(`SELECT COUNT(*)::int AS n FROM articles WHERE status = 'approved'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM profiles WHERE status = 'approved'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM editions WHERE status = 'published'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM gallery_images WHERE status = 'approved'`),
      pool.query(`SELECT COUNT(*)::int AS n, COALESCE(SUM(amount), 0)::numeric AS amount
                    FROM payments WHERE method = 'eft' AND status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM articles WHERE status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM profiles WHERE status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM gallery_images WHERE status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM profile_claims WHERE status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM profile_reviews WHERE status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM content_comments WHERE status = 'pending'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM page_views WHERE viewed_at >= now() - interval '7 days'`),
      pool.query(`SELECT COUNT(*)::int AS n FROM admin_notifications WHERE read = false`),
    ]);

    // Recent submissions across content types, newest first — the "what just
    // came in" feed the brief asks for, built from tables that already exist
    // rather than a new activity-log entry type.
    const recent = await pool.query(
      `SELECT * FROM (
          SELECT id, title AS label, 'article' AS kind, status, created_at FROM articles
          UNION ALL
          SELECT id, display_name AS label, 'profile' AS kind, status, created_at FROM profiles
          UNION ALL
          SELECT id, COALESCE(caption, 'Untitled photo') AS label, 'gallery' AS kind, status, created_at FROM gallery_images
        ) recent
        ORDER BY created_at DESC
        LIMIT 10`
    );

    res.json({
      totals: {
        users: can('members.view','members.manage') ? users.rows[0].n : null,
        articles: can('content.view','content.manage') ? articles.rows[0].n : null,
        profiles: can('directory.manage') ? profiles.rows[0].n : null,
        editions: can('content.view','content.manage') ? editions.rows[0].n : null,
        gallery: can('media.manage') ? gallery.rows[0].n : null,
      },
      pending: can('approvals.view','approvals.manage') ? {
        articles: pendingArticles.rows[0].n, profiles: pendingProfiles.rows[0].n, gallery: pendingGallery.rows[0].n,
        claims: pendingClaims.rows[0].n, reviews: pendingReviews.rows[0].n, comments: pendingComments.rows[0].n,
        total: pendingArticles.rows[0].n + pendingProfiles.rows[0].n + pendingGallery.rows[0].n
          + pendingClaims.rows[0].n + pendingReviews.rows[0].n + pendingComments.rows[0].n,
      } : null,
      payments: can('finance.view','finance.manage') ? {
        pendingEftCount: pendingEft.rows[0].n, pendingEftAmount: Number(pendingEft.rows[0].amount),
      } : null,
      activity: {
        views7d: can('analytics.view') ? views7d.rows[0].n : null,
        unreadNotifications: unreadNotifications.rows[0].n,
      },
      recentSubmissions: can('approvals.view','approvals.manage') ? recent.rows : [],
    });
  } catch (err) {
    next(err);
  }
});

router.get('/notifications', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      // last_seen_at, not created_at: a rolled-up row's created_at is when the
      // FIRST of its events arrived, so ordering by it would sink an active
      // thread to the bottom while it was still filling up.
      `SELECT id, type, message, detail, link_section, dedupe_key, event_count,
              read, created_at, COALESCE(last_seen_at, created_at) AS last_seen_at
         FROM admin_notifications
        ORDER BY read ASC, COALESCE(last_seen_at, created_at) DESC
        LIMIT 100`
    );
    res.json({ notifications: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/notifications/:id/read
router.patch('/notifications/:id/read', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE admin_notifications SET read = true WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Notification not found.' });
    }
    res.json({ notification: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/settings — every platform setting (currently just the Bundle
// Vote price, but this grows into a general config screen over time).
router.get('/settings', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(`SELECT key, value, updated_at FROM settings ORDER BY key ASC`);
    res.json({ settings: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/settings/:key — update a single setting. Kept generic
// (rather than a dedicated bundle-vote-price endpoint) so future settings
// don't each need their own route.
router.patch('/settings/:key', requireRole('admin'), async (req, res, next) => {
  try {
    const { value } = req.body;
    if (value === undefined || value === null) {
      return res.status(400).json({ error: 'value is required.' });
    }
    if (req.params.key === 'bundle_vote_price' && (value === '' || isNaN(parseFloat(value)))) {
      return res.status(400).json({ error: 'bundle_vote_price must be a number.' });
    }
    // Same 8-value vocabulary every other part of this feature uses.
    if (req.params.key === 'feature_edition_animation_effect') {
      const ALLOWED_ANIM = ['none', 'fade', 'fade-up', 'slide-up', 'slide-down', 'slide-left', 'slide-right', 'zoom'];
      if (!ALLOWED_ANIM.includes(value)) {
        return res.status(400).json({ error: 'feature_edition_animation_effect must be one of: ' + ALLOWED_ANIM.join(', ') });
      }
    }
    if (req.params.key === 'feature_edition_transition_duration_ms'
        && !(Number.isInteger(Number(value)) && Number(value) > 0)) {
      return res.status(400).json({ error: 'feature_edition_transition_duration_ms must be a positive whole number of milliseconds.' });
    }

    const result = await pool.query(
      `UPDATE settings SET value = $1, updated_at = now() WHERE key = $2 RETURNING *`,
      [String(value), req.params.key]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: `Setting "${req.params.key}" does not exist.` });
    }
    res.json({ setting: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/top10-entries/pending — paid Top 10 consideration requests
// waiting on admin review (separate from publishing the actual rankings).
router.get('/top10-entries/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT te.id, te.entry_fee, te.created_at, p.display_name
       FROM top10_entries te
       JOIN profiles p ON p.id = te.profile_id
       WHERE te.status = 'pending'
       ORDER BY te.created_at ASC`
    );
    res.json({ entries: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/top10-entries/:id/approve
router.patch('/top10-entries/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE top10_entries SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Entry not found.' });
    }
    res.json({ entry: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/top10-entries/:id/reject
router.patch('/top10-entries/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE top10_entries SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Entry not found.' });
    }
    res.json({ entry: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/shoutouts/pending — public shoutout nominations awaiting review.
// Approving one adds it to the daily rotation on the homepage.
router.get('/shoutouts/pending', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, nominee_name, message, submitted_by_email,
              nominee_social, nominee_social_url, created_at
       FROM shoutout_nominations
       WHERE status = 'pending'
       ORDER BY created_at ASC`
    );
    res.json({ nominations: result.rows });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/shoutouts/:id/approve — enters the nomination into rotation.
router.patch('/shoutouts/:id/approve', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE shoutout_nominations SET status = 'approved' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Nomination not found.' });
    }
    res.json({ nomination: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// PATCH /admin/shoutouts/:id/reject
router.patch('/shoutouts/:id/reject', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE shoutout_nominations SET status = 'rejected' WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Nomination not found.' });
    }
    res.json({ nomination: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// GET /admin/shoutouts — every shout-out in one list, each with the date it
// ran or is expected to run.
//
// The expected date is an ESTIMATE and is labelled as one. The homepage shows
// one shout-out per day and takes the head of the queue, so position in the
// queue is the number of days away — but that only holds if nothing is
// approved, rejected or added ahead of it in the meantime. It is a planning
// aid, not a promise to the nominee.
router.get('/shoutouts', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `WITH queue AS (
         SELECT n.id,
                ROW_NUMBER() OVER (ORDER BY n.created_at ASC) AS position
           FROM shoutout_nominations n
          WHERE n.status = 'approved'
            AND NOT EXISTS (SELECT 1 FROM shoutout_schedule s WHERE s.nomination_id = n.id)
       )
       SELECT n.id, n.nominee_name, n.message, n.submitted_by_email,
              n.status, n.source, n.created_at, n.available_from,
              sch.shoutout_date AS shown_on,
              CASE
                WHEN sch.shoutout_date IS NOT NULL THEN NULL
                WHEN n.status <> 'approved' THEN NULL
                -- Whichever comes later: the end of the waiting period, or the
                -- day its turn in the queue comes up.
                ELSE GREATEST(n.available_from, CURRENT_DATE + q.position::int)
              END AS estimated_date
         FROM shoutout_nominations n
         LEFT JOIN shoutout_schedule sch ON sch.nomination_id = n.id
         LEFT JOIN queue q ON q.id = n.id
        ORDER BY n.created_at DESC
        LIMIT 300`
    );
    res.json({ shoutouts: result.rows });
  } catch (err) {
    next(err);
  }
});

// POST /admin/shoutouts — admin adds a shout-out directly.
//
// Goes in approved and available immediately: an admin adding a name IS the
// editorial decision, so there is nothing to review and no reason to wait.
router.post('/shoutouts', requireRole('admin'), async (req, res, next) => {
  try {
    const name = (req.body.nomineeName || '').trim();
    const message = (req.body.message || '').trim();
    if (!name) return res.status(400).json({ error: 'A name and surname are required.' });
    if (name.length > 200) return res.status(400).json({ error: 'That name is too long.' });

    const result = await pool.query(
      `INSERT INTO shoutout_nominations
         (nominee_name, message, status, source, available_from)
       VALUES ($1, $2, 'approved', 'admin', CURRENT_DATE)
       RETURNING *`,
      [name, message || null]
    );
    res.status(201).json({ shoutout: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/shoutouts/:id — remove a shout-out entirely.
//
// A shout-out that has already run is history and stays: shoutout_schedule
// references it, and deleting it would blank out the record of what the
// homepage showed that day. Reject it instead if it should not run again.
router.delete('/shoutouts/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const used = await pool.query('SELECT 1 FROM shoutout_schedule WHERE nomination_id = $1', [req.params.id]);
    if (used.rowCount > 0) {
      return res.status(409).json({
        error: 'This shout-out has already been shown on the homepage, so it is kept as a record. Reject it instead to stop it running again.',
      });
    }
    const result = await pool.query('DELETE FROM shoutout_nominations WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rowCount === 0) return res.status(404).json({ error: 'Nomination not found.' });
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
});

// GET /admin/email-status — is outgoing email actually configured? Signup
// verification and password resets depend on it, and when it's missing the
// failure is invisible: codes get written to the server log and the member
// just never receives anything. This makes that state checkable.
router.get('/email-status', requireRole('admin'), async (req, res) => {
  const configured = isConfigured();
  if (!configured) {
    return res.json({
      configured: false,
      connectionOk: false,
      message: 'SMTP is not set up. Verification codes and password resets are being written to the server log instead of sent, so new members cannot verify their accounts.',
      marketing: marketingStatus(),
    });
  }
  const cfg = emailConfig();
  // Name the transport that's actually in use. Saying "SMTP" while sending
  // over an HTTPS API would send the next person debugging this down exactly
  // the wrong path.
  const label = cfg.provider === 'smtp' ? 'SMTP' : `The ${cfg.provider} API`;
  try {
    await verifyConnection();
    res.json({
      configured: true,
      connectionOk: true,
      config: cfg,
      marketing: marketingStatus(),
      message: cfg.provider === 'smtp'
        ? 'SMTP is configured and the mail server accepted our credentials.'
        : `${label} is configured and accepted our key.`,
    });
  } catch (err) {
    // Configured but not working is the most dangerous state — it looks fine
    // from the outside, so report the reason AND the settings in use, which
    // is the quickest way to see whether an env change actually took effect.
    res.json({
      configured: true,
      connectionOk: false,
      config: cfg,
      marketing: marketingStatus(),
      message: `${label} is configured but failed: ${err.message}`,
    });
  }
});

// GET /admin/smtp-probe — can this server reach mail ports at all?
//
// "Connection timeout" looks the same whether the host blocks outbound SMTP
// or the mail server is refusing us, and that distinction decides the whole
// approach: a host-wide block means no SMTP provider will ever work and we
// must send over HTTPS, while a single unreachable mail server means another
// SMTP provider (e.g. Gmail) is still fine. Testing several targets from
// here is the only way to tell. No credentials are used — this opens a TCP
// connection and immediately closes it.
router.get('/smtp-probe', requireRole('admin'), async (req, res, next) => {
  try {
    const targets = [
      ['mail.unplugnews.com', 465],
      ['cp73.domains.co.za', 465],
      ['smtp.gmail.com', 465],
      ['smtp.gmail.com', 587],
      // Control: HTTPS must succeed, otherwise the probe itself is meaningless.
      ['api.resend.com', 443],
    ];
    const results = await Promise.all(targets.map(([h, p]) => probe(h, p)));
    const mailPorts = results.filter((r) => r.port !== 443);
    const anyMailOpen = mailPorts.some((r) => r.result === 'open');
    const httpsOk = results.some((r) => r.port === 443 && r.result === 'open');
    res.json({
      results,
      verdict: !httpsOk
        ? 'Outbound networking looks broken entirely — even HTTPS failed, so treat these results with suspicion.'
        : anyMailOpen
          ? 'This server CAN reach some mail servers, so outbound SMTP is not blocked host-wide. The specific mail server that timed out is the problem — another SMTP provider would work.'
          : 'This server cannot reach ANY mail port while HTTPS works, so outbound SMTP is blocked here. Email must be sent over an HTTPS API (Resend or Brevo).',
    });
  } catch (err) {
    next(err);
  }
});

// POST /admin/test-email — sends a real test message to the signed-in admin's
// own address. Deliberately only to their own address: this endpoint must not
// become a way to send mail to arbitrary people.
router.post('/test-email', requireRole('admin'), async (req, res, next) => {
  try {
    if (!isConfigured()) {
      return res.status(400).json({ error: 'SMTP is not set up yet, so there is nothing to test.' });
    }
    const to = req.user.email;
    await sendEmail({
      to,
      subject: 'Unplug — test email',
      text: 'This is a test from your Unplug admin dashboard.\n\n'
        + 'If you are reading this, outgoing email is working: signup verification '
        + 'codes and password resets will reach your members.\n\n— Unplug',
    });
    logActivity(req.user.id, 'test_email_sent', to);
    res.json({ sent: true, to, message: `Test email sent to ${to}. If it doesn't arrive within a minute, check the spam folder.` });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// Interaction moderation (Members/Community System, brief item 11) — an
// admin looks up everything on one target (a reported profile, article,
// etc.), then removes an individual reaction or save. Comments already have
// their own admin-capable DELETE /comments/:id, so they aren't duplicated
// here — this panel's comment list, when shown, calls that existing route.
// ---------------------------------------------------------------------------
const INTERACTION_TARGET_TYPES = ['article', 'profile', 'gallery_image', 'event', 'marketplace_listing'];

// GET /admin/interactions/:targetType/:targetId — every reaction and save
// on one piece of content, with who did it, for moderation review.
router.get('/interactions/:targetType/:targetId', requireRole('admin'), async (req, res, next) => {
  try {
    const targetType = req.params.targetType;
    const targetId = Number(req.params.targetId);
    if (!INTERACTION_TARGET_TYPES.includes(targetType)) {
      return res.status(400).json({ error: `targetType must be one of: ${INTERACTION_TARGET_TYPES.join(', ')}` });
    }
    if (!Number.isInteger(targetId)) {
      return res.status(400).json({ error: 'A valid targetId is required.' });
    }
    const [reactions, saves] = await Promise.all([
      pool.query(
        `SELECT cr.id, cr.reaction, cr.created_at, u.id AS user_id, u.email, u.full_name
           FROM content_reactions cr JOIN users u ON u.id = cr.user_id
          WHERE cr.target_type = $1 AND cr.target_id = $2
          ORDER BY cr.created_at DESC`,
        [targetType, targetId]
      ),
      pool.query(
        `SELECT cs.id, cs.saved_at, u.id AS user_id, u.email, u.full_name
           FROM content_saves cs JOIN users u ON u.id = cs.user_id
          WHERE cs.target_type = $1 AND cs.target_id = $2
          ORDER BY cs.saved_at DESC`,
        [targetType, targetId]
      ),
    ]);
    res.json({ reactions: reactions.rows, saves: saves.rows });
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/interactions/reactions/:id — remove one like/dislike.
router.delete('/interactions/reactions/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid id is required.' });
    await pool.query('DELETE FROM content_reactions WHERE id = $1', [id]);
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
});

// DELETE /admin/interactions/saves/:id — remove one save.
router.delete('/interactions/saves/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'A valid id is required.' });
    await pool.query('DELETE FROM content_saves WHERE id = $1', [id]);
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
});

// GET /admin/storage-audit — N-3: find any stored URL still pointing at the
// OLDER Supabase project (fkuzbwysvyskhsskjmmi) rather than production
// (jaywxegcxjgyqhcwzbte). This can't be answered from the codebase alone —
// grepped every migration/route/HTML file for the old project ref and found
// nothing hardcoded, so any stale URL exists only as data an admin typed in
// at some point (e.g. a site-settings image field), and only live database
// access can see it. This is that access, from inside the app itself.
//
// Rather than hand-list every *_url/*_image_url column (this schema has
// dozens, across dozens of tables, and a hand-built list goes stale the
// moment a new one is added), the columns to check are discovered from the
// database's own catalog: every text-like column whose name contains "url".
// Table/column names come from information_schema, never from the request,
// so building each per-column query by interpolating them is safe.
router.get('/storage-audit', requireRole('admin'), async (req, res, next) => {
  try {
    const needle = (req.query.host || 'fkuzbwysvyskhsskjmmi').toString();

    const cols = await pool.query(
      `SELECT table_name, column_name
         FROM information_schema.columns
        WHERE table_schema = 'public'
          AND data_type IN ('character varying', 'text')
          AND column_name ILIKE '%url%'
        ORDER BY table_name, column_name`
    );

    // settings is a generic key/value table — its URL-shaped content (e.g.
    // youtube_image_url) lives in a column literally named "value", which
    // the name-based discovery above can never match. Checked explicitly,
    // since it's the one place in this schema an arbitrary URL can hide
    // behind a column name that gives no hint of what it holds.
    const columnsToCheck = [...cols.rows, { table_name: 'settings', column_name: 'value' }];

    const findings = [];
    for (const { table_name: table, column_name: column } of columnsToCheck) {
      try {
        // settings is a key/value table with no "id" column — its own key
        // IS the identifier, so it's addressed differently from every
        // other table here (which all use a plain serial "id").
        const idCol = table === 'settings' ? 'key' : 'id';
        const r = await pool.query(
          `SELECT "${idCol}" AS row_id, "${column}" AS value
             FROM "${table}"
            WHERE "${column}" ILIKE $1
            LIMIT 20`,
          [`%${needle}%`]
        );
        r.rows.forEach((row) => {
          findings.push({ table, column, rowId: row.row_id, value: row.value });
        });
      } catch (e) {
        // A column that turns out not to be simply queryable this way (no
        // "id"/"key", or a permissions quirk) is skipped rather than
        // failing the whole audit — this is a best-effort sweep, not a
        // guarantee every column was reachable.
      }
    }

    res.json({
      searchedHost: needle,
      columnsChecked: columnsToCheck.length,
      findings,
      note: findings.length === 0
        ? `No stored value contains "${needle}" across ${columnsToCheck.length} URL-shaped columns checked. This does not prove nothing is stale (a column named differently, e.g. without "url" in its name, would not be checked) but nothing obvious was found.`
        : `${findings.length} value(s) still reference "${needle}" — these are real rows to fix or re-upload to the production storage bucket.`,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
