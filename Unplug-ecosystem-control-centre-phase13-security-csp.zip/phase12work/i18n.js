// Unplug — interface translations.
//
// Scope, deliberately: this translates the SITE INTERFACE — navigation,
// buttons, section headings, form labels — not the editorial content.
// Articles, profiles and shout-outs are written by people in the language
// they chose, and machine-translating someone's story would misrepresent
// them. A reader can therefore navigate the site in their own language and
// still read each piece as it was written.
//
// Afrikaans, isiXhosa and isiZulu are South Africa's most widely spoken
// languages after English here. These strings should be reviewed by a
// first-language speaker before launch — they are careful translations, not
// certified ones, and UI wording is easy to get subtly wrong.

const I18N = {
  en: {
    _label: 'English',
    'nav.home': 'Home',
    'nav.news': 'Latest News',
    'nav.directory': 'Directory',
    'nav.gallery': 'Gallery',
    'nav.editions': 'Editions',
    'nav.top10': 'Top 10',
    'nav.competitions': 'Competitions',
    'nav.investors': 'Investors',
    'nav.marketplace': 'Marketplace',
    'nav.nominate': 'Nominate',
    'nav.deafcommunity': 'Deaf Community',
    'nav.members': 'Members',
    'nav.about': 'About',
    'nav.contact': 'Contact',
    'nav.refunds': 'Terms & Policies',
    'nav.group.read': 'Read',
    'nav.group.community': 'Community',
    'nav.group.takepart': 'Take Part',
    'nav.group.business': 'Business',
    'nav.group.about': 'About',
    'nav.news.desc': 'Stories from around the country',
    'nav.editions.desc': 'Read and download the magazine',
    'nav.gallery.desc': 'Pictures from the community',
    'nav.directory.desc': 'Find people and businesses',
    'nav.members.desc': 'Everyone with an Unplug profile',
    'nav.deafcommunity.desc': 'Jobs, SASL and the Passport',
    'nav.competitions.desc': 'What is open to enter now',
    'nav.top10.desc': 'This month’s most-voted',
    'nav.nominate.desc': 'Tell us about someone',
    'nav.marketplace.desc': 'Advertise with us',
    'nav.investors.desc': 'Projects and sponsorships',
    'nav.about.desc': 'Who we are',
    'nav.contact.desc': 'Get in touch',
    'nav.refunds.desc': 'Terms, refunds and privacy',
    'home.featured.title': 'Featured Stories',
    'home.social.title': 'Follow Unplug everywhere',
    'search.title': 'Search Unplug',
    'directory.packages.title': 'Directory Packages',
    'ui.search': 'Search',
    'ui.readMore': 'Read more',
    'ui.viewAll': 'View all',
    'ui.share': 'Share:',
    'ui.loading': 'Loading…',
    'ui.close': 'Close',
    'ui.submit': 'Submit',
    'ui.signIn': 'Sign in',
    'ui.minRead': 'min read',
    'ui.language': 'Language',
    'home.newstories.title': 'New Stories',
    'home.calendar.title': 'Calendar Events',
    'home.birthdays.title': "Birthdays we're unplugging for",
    'home.top10.title': "This Month's Top 10",
    'home.arena.title': 'The Arena',
    'home.halloffame.title': 'Hall of Fame',
    'home.youtube.title': 'Our stories, now on screen',
    'home.goodnews.title': 'The good news desk',
    'directory.title': 'People making it happen',
    'consent.title': 'Before you start reading',
    'consent.note': "By accepting this, we will only collect analytics to improve our site.",
    'consent.text': "We'd like to count visits so we know which stories land. It's anonymous, and entirely your choice — the site works exactly the same either way.",
    'consent.accept': 'Allow',
    'consent.decline': 'No thanks',
    'consent.privacy': 'Read our privacy policy',
  },

  af: {
    _label: 'Afrikaans',
    'nav.home': 'Tuis',
    'nav.news': 'Jongste Nuus',
    'nav.directory': 'Gids',
    'nav.gallery': 'Galery',
    'nav.editions': 'Uitgawes',
    'nav.top10': 'Top 10',
    'nav.competitions': 'Kompetisies',
    'nav.investors': 'Beleggers',
    'nav.marketplace': 'Markplein',
    'nav.nominate': 'Nomineer',
    'nav.deafcommunity': 'Dowe Gemeenskap',
    'nav.members': 'Lede',
    'nav.about': 'Oor Ons',
    'nav.contact': 'Kontak',
    'nav.refunds': 'Bepalings & Beleide',
    'nav.group.read': 'Lees',
    'nav.group.community': 'Gemeenskap',
    'nav.group.takepart': 'Neem Deel',
    'nav.group.business': 'Besigheid',
    'nav.group.about': 'Oor Ons',
    'nav.news.desc': 'Stories van regoor die land',
    'nav.editions.desc': 'Lees en laai die tydskrif af',
    'nav.gallery.desc': 'Foto’s uit die gemeenskap',
    'nav.directory.desc': 'Vind mense en besighede',
    'nav.members.desc': 'Almal met ’n Unplug-profiel',
    'nav.deafcommunity.desc': 'Werk, SASL en die Paspoort',
    'nav.competitions.desc': 'Wat nou oop is om in te skryf',
    'nav.top10.desc': 'Hierdie maand se meeste stemme',
    'nav.nominate.desc': 'Vertel ons van iemand',
    'nav.marketplace.desc': 'Adverteer by ons',
    'nav.investors.desc': 'Projekte en borgskappe',
    'nav.about.desc': 'Wie ons is',
    'nav.contact.desc': 'Kom in kontak',
    'nav.refunds.desc': 'Bepalings, terugbetalings en privaatheid',
    'home.featured.title': 'Uitgesoekte Stories',
    'home.social.title': 'Volg Unplug oral',
    'search.title': 'Soek Unplug',
    'directory.packages.title': 'Gidspakkette',
    'ui.search': 'Soek',
    'ui.readMore': 'Lees meer',
    'ui.viewAll': 'Sien alles',
    'ui.share': 'Deel:',
    'ui.loading': 'Laai tans…',
    'ui.close': 'Maak toe',
    'ui.submit': 'Dien in',
    'ui.signIn': 'Teken in',
    'ui.minRead': 'min lees',
    'ui.language': 'Taal',
    'home.newstories.title': 'Nuwe Stories',
    'home.calendar.title': 'Kalender Gebeure',
    'home.birthdays.title': 'Verjaarsdae wat ons vier',
    'home.top10.title': 'Hierdie Maand se Top 10',
    'home.arena.title': 'Die Arena',
    'home.halloffame.title': 'Eregalery',
    'home.youtube.title': 'Ons stories, nou op die skerm',
    'home.goodnews.title': 'Die goeie nuus toonbank',
    'directory.title': 'Mense wat dit laat gebeur',
    'consent.title': 'Voor jy begin lees',
    'consent.note': 'Deur dit te aanvaar, sal ons slegs analitiese data insamel om ons webwerf te verbeter.',
    'consent.text': 'Ons wil graag besoeke tel sodat ons weet watter stories aanklank vind. Dit is anoniem, en heeltemal jou keuse — die webwerf werk presies dieselfde met of daarsonder.',
    'consent.accept': 'Laat toe',
    'consent.decline': 'Nee dankie',
    'consent.privacy': 'Lees ons privaatheidsbeleid',
  },

  xh: {
    _label: 'isiXhosa',
    'nav.home': 'Ikhaya',
    'nav.news': 'Iindaba Zamva',
    'nav.directory': 'Uluhlu',
    'nav.gallery': 'Igalari',
    'nav.editions': 'Iipapasho',
    'nav.top10': 'Ishumi Eliphezulu',
    'nav.competitions': 'Ukhuphiswano',
    'nav.investors': 'Abatyali-mali',
    'nav.marketplace': 'Indawo Yentengiso',
    'nav.nominate': 'Tyumba',
    'nav.deafcommunity': 'Uluntu Olusithulu',
    'nav.members': 'Amalungu',
    'nav.about': 'Ngathi',
    'nav.contact': 'Qhagamshelana',
    'nav.refunds': 'Imimiselo & Imigaqo-nkqubo',
    'nav.group.read': 'Funda',
    'nav.group.community': 'Uluntu',
    'nav.group.takepart': 'Thabatha Inxaxheba',
    'nav.group.business': 'Ishishini',
    'nav.group.about': 'Ngathi',
    'nav.news.desc': 'Amabali avela kulo lonke ilizwe',
    'nav.editions.desc': 'Funda kwaye ukhuphele imagazini',
    'nav.gallery.desc': 'Imifanekiso evela eluntwini',
    'nav.directory.desc': 'Fumana abantu namashishini',
    'nav.members.desc': 'Wonke umntu onephrofayile ye-Unplug',
    'nav.deafcommunity.desc': 'Imisebenzi, i-SASL kunye nePasipoti',
    'nav.competitions.desc': 'Okuvulekileyo ukungenela ngoku',
    'nav.top10.desc': 'Abavotelwe kakhulu kule nyanga',
    'nav.nominate.desc': 'Sixelele ngomntu',
    'nav.marketplace.desc': 'Yenza intengiso nathi',
    'nav.investors.desc': 'Iiprojekthi kunye noxhaso',
    'nav.about.desc': 'Singoobani',
    'nav.contact.desc': 'Qhagamshelana nathi',
    'nav.refunds.desc': 'Imimiselo, imbuyekezo nabucala',
    'home.featured.title': 'Amabali Akhethiweyo',
    'home.social.title': 'Landela i-Unplug yonke indawo',
    'search.title': 'Khangela ku-Unplug',
    'directory.packages.title': 'Iiphakheji Zoluhlu',
    'ui.search': 'Khangela',
    'ui.readMore': 'Funda ngokugqithisileyo',
    'ui.viewAll': 'Jonga konke',
    'ui.share': 'Yabelana:',
    'ui.loading': 'Iyalayisha…',
    'ui.close': 'Vala',
    'ui.submit': 'Ngenisa',
    'ui.signIn': 'Ngena',
    'ui.minRead': 'imizuzu yokufunda',
    'ui.language': 'Ulwimi',
    'home.newstories.title': 'Amabali Amatsha',
    'home.calendar.title': 'Iziganeko Zekhalenda',
    'home.birthdays.title': 'Iimini zokuzalwa esizibhiyozelayo',
    'home.top10.title': 'Ishumi Eliphezulu Lale Nyanga',
    'home.arena.title': 'I-Arena',
    'home.halloffame.title': 'Iholo Lodumo',
    'home.youtube.title': 'Amabali ethu, ngoku esikrinini',
    'home.goodnews.title': 'Idesika yeendaba ezimnandi',
    'directory.title': 'Abantu abenza kwenzeke',
    'consent.title': 'Phambi kokuba uqalise ukufunda',
    'consent.note': 'Ngokwamkela oku, siza kuqokelela kuphela idatha yohlalutyo ukuphucula iwebhusayithi yethu.',
    'consent.text': 'Singathanda ukubala utyelelo ukuze sazi ukuba ngawaphi amabali afikelelayo. Akukho magama abonisa ukuba ungubani, kwaye kukhetho lwakho ngokupheleleyo — iwebhusayithi isebenza ngendlela efanayo nokuba ukhetha ntoni.',
    'consent.accept': 'Vumela',
    'consent.decline': 'Hayi enkosi',
    'consent.privacy': 'Funda umgaqo-nkqubo wabucala',
  },

  zu: {
    _label: 'isiZulu',
    'nav.home': 'Ikhaya',
    'nav.news': 'Izindaba Zakamuva',
    'nav.directory': 'Uhlu',
    'nav.gallery': 'Igalari',
    'nav.editions': 'Izinhlelo',
    'nav.top10': 'Ishumi Eliphezulu',
    'nav.competitions': 'Imincintiswano',
    'nav.investors': 'Abatshalizimali',
    'nav.marketplace': 'Indawo Yokuthengisa',
    'nav.nominate': 'Phakamisa',
    'nav.deafcommunity': 'Umphakathi Wezithulu',
    'nav.members': 'Amalungu',
    'nav.about': 'Mayelana Nathi',
    'nav.contact': 'Xhumana Nathi',
    'nav.refunds': 'Imigomo & Izinqubomgomo',
    'nav.group.read': 'Funda',
    'nav.group.community': 'Umphakathi',
    'nav.group.takepart': 'Bamba Iqhaza',
    'nav.group.business': 'Ibhizinisi',
    'nav.group.about': 'Mayelana',
    'nav.news.desc': 'Izindaba ezivela ezweni lonke',
    'nav.editions.desc': 'Funda futhi ulande umagazini',
    'nav.gallery.desc': 'Izithombe ezivela emphakathini',
    'nav.directory.desc': 'Thola abantu namabhizinisi',
    'nav.members.desc': 'Wonke umuntu onephrofayela ye-Unplug',
    'nav.deafcommunity.desc': 'Imisebenzi, i-SASL nePhasipoti',
    'nav.competitions.desc': 'Okuvulekile ukungenela manje',
    'nav.top10.desc': 'Abavotelwe kakhulu kule nyanga',
    'nav.nominate.desc': 'Sitshele ngomuntu',
    'nav.marketplace.desc': 'Khangisa nathi',
    'nav.investors.desc': 'Amaphrojekthi noxhaso',
    'nav.about.desc': 'Singobani',
    'nav.contact.desc': 'Xhumana nathi',
    'nav.refunds.desc': 'Imigomo, izimbuyiselo nobumfihlo',
    'home.featured.title': 'Izindaba Ezikhethiwe',
    'home.social.title': 'Landela i-Unplug yonke indawo',
    'search.title': 'Sesha ku-Unplug',
    'directory.packages.title': 'Amaphakheji Ohlu',
    'ui.search': 'Sesha',
    'ui.readMore': 'Funda kabanzi',
    'ui.viewAll': 'Buka konke',
    'ui.share': 'Yabelana:',
    'ui.loading': 'Iyalayisha…',
    'ui.close': 'Vala',
    'ui.submit': 'Thumela',
    'ui.signIn': 'Ngena',
    'ui.minRead': 'imizuzu yokufunda',
    'ui.language': 'Ulimi',
    'home.newstories.title': 'Izindaba Ezintsha',
    'home.calendar.title': 'Imicimbi Yekhalenda',
    'home.birthdays.title': 'Usuku lokuzalwa esilugubhayo',
    'home.top10.title': 'Ishumi Eliphezulu Lale Nyanga',
    'home.arena.title': 'I-Arena',
    'home.halloffame.title': 'Ihholo Lodumo',
    'home.youtube.title': 'Izindaba zethu, manje esikrinini',
    'home.goodnews.title': 'Ideski lezindaba ezinhle',
    'directory.title': 'Abantu abakwenzayo',
    'consent.title': 'Ngaphambi kokuthi uqale ukufunda',
    'consent.note': 'Ngokwamukela lokhu, sizoqoqa kuphela idatha yokuhlaziya ukuze sithuthukise iwebhusayithi yethu.',
    'consent.text': 'Singathanda ukubala ukuvakasha ukuze sazi ukuthi yiziphi izindaba ezifinyelelayo. Akudalulwa ukuthi ungubani, futhi kuwukukhetha kwakho ngokuphelele — iwebhusayithi isebenza ngendlela efanayo noma ngabe ukhetha kanjani.',
    'consent.accept': 'Vumela',
    'consent.decline': 'Cha ngiyabonga',
    'consent.privacy': 'Funda inqubomgomo yobumfihlo',
  },

  // ---------------------------------------------------------------------
  // PARTIAL BY DESIGN.
  //
  // These three carry the navigation and the common interface words, and
  // nothing else. Every other key falls through to English, one key at a
  // time, which is exactly what t() and hasTranslation() are built to do.
  //
  // That is a deliberate stop, not an unfinished job. The keys left out are
  // the ones where a confident-looking wrong word does real damage — the
  // Deaf Community section, SASL, the legal and refund wording. Guessing at
  // Deaf terminology in a language I cannot verify would be worse than
  // showing the English, and this publication of all publications should not
  // get that wrong.
  //
  // These are careful translations, NOT certified ones. A first-language
  // speaker should review them before launch, and can fill in the rest at
  // the same time. See MULTILINGUAL.md.
  // ---------------------------------------------------------------------
  st: {
    _label: 'Sesotho',
    'nav.home': 'Lehae',
    'nav.news': 'Litaba tsa Morao Tjena',
    'nav.directory': 'Bukana ya Mabitso',
    'nav.gallery': 'Galeri',
    'nav.editions': 'Dikhatiso',
    'nav.competitions': 'Ditlhodisano',
    'nav.investors': 'Batsetedi',
    'nav.marketplace': 'Mmaraka',
    'nav.members': 'Ditho',
    'nav.about': 'Ka Rona',
    'nav.contact': 'Ikopanye le Rona',
    'nav.group.read': 'Bala',
    'nav.group.community': 'Setjhaba',
    'nav.group.takepart': 'Nka Karolo',
    'nav.group.business': 'Kgwebo',
    'nav.group.about': 'Ka Rona',
    'ui.search': 'Batla',
    'ui.readMore': 'Bala ho eketsehileng',
    'ui.viewAll': 'Sheba tsohle',
    'ui.share': 'Arolelana:',
    'ui.close': 'Koala',
    'ui.submit': 'Romela',
    'ui.signIn': 'Kena',
    'ui.language': 'Puo',
  },

  tn: {
    _label: 'Setswana',
    'nav.home': 'Gae',
    'nav.news': 'Dikgang tsa Bosheng',
    'nav.directory': 'Lenaneo la Maina',
    'nav.gallery': 'Galere',
    'nav.editions': 'Dikgatiso',
    'nav.competitions': 'Dikgaisano',
    'nav.investors': 'Batsetedi',
    'nav.marketplace': 'Mmaraka',
    'nav.members': 'Maloko',
    'nav.about': 'Ka ga Rona',
    'nav.contact': 'Ikgolaganye le Rona',
    'nav.group.read': 'Bala',
    'nav.group.community': 'Setšhaba',
    'nav.group.takepart': 'Nna le Seabe',
    'nav.group.business': 'Kgwebo',
    'nav.group.about': 'Ka ga Rona',
    'ui.search': 'Batla',
    'ui.readMore': 'Bala go oketsegileng',
    'ui.viewAll': 'Leba tsotlhe',
    'ui.share': 'Abelana:',
    'ui.close': 'Tswala',
    'ui.submit': 'Romela',
    'ui.signIn': 'Tsena',
    'ui.language': 'Puo',
  },

  nso: {
    _label: 'Sepedi',
    'nav.home': 'Gae',
    'nav.news': 'Ditaba tša Bjale',
    'nav.directory': 'Lenaneo la Maina',
    'nav.gallery': 'Galeri',
    'nav.editions': 'Dikgatišo',
    'nav.competitions': 'Diphadišano',
    'nav.investors': 'Batsenyaletšadi',
    'nav.marketplace': 'Mmaraka',
    'nav.members': 'Maloko',
    'nav.about': 'Ka ga Rena',
    'nav.contact': 'Ikgokaganye le Rena',
    'nav.group.read': 'Bala',
    'nav.group.community': 'Setšhaba',
    'nav.group.takepart': 'Tšea Karolo',
    'nav.group.business': 'Kgwebo',
    'nav.group.about': 'Ka ga Rena',
    'ui.search': 'Nyaka',
    'ui.readMore': 'Bala go oketšegilego',
    'ui.viewAll': 'Lebelela tšohle',
    'ui.share': 'Abelana:',
    'ui.close': 'Tswalela',
    'ui.submit': 'Romela',
    'ui.signIn': 'Tsena',
    'ui.language': 'Polelo',
  },
};

const I18N_KEY = 'unplug_lang';

function currentLang() {
  try {
    const saved = localStorage.getItem(I18N_KEY);
    if (saved && I18N[saved]) return saved;
  } catch (e) { /* private mode */ }
  // Fall back to the browser's language when we support it, so a Zulu or
  // Afrikaans speaker doesn't have to go looking for the switcher.
  const browser = (navigator.language || 'en').slice(0, 2).toLowerCase();
  return I18N[browser] ? browser : 'en';
}

function t(key, lang) {
  const code = lang || currentLang();
  // Fall back to English rather than showing a raw key — a missing
  // translation should degrade to readable text, not to "nav.home".
  return (I18N[code] && I18N[code][key]) || I18N.en[key] || key;
}

// Whether a key is actually translated anywhere, as opposed to t() having
// fallen through to returning the key itself.
//
// This distinction matters because applyLanguage() below writes into
// elements that ALREADY contain correct English in the markup. Without this
// check, a key that nobody added to the dictionary doesn't degrade to the
// English in the HTML — it actively replaces it with the raw dotted key, so
// the nav reads "NAV.MEMBERS" instead of "Members". That is strictly worse
// than doing nothing, and it fails silently in every language at once.
function hasTranslation(key, lang) {
  const code = lang || currentLang();
  return Boolean((I18N[code] && I18N[code][key]) || I18N.en[key]);
}

// Applies the active language to anything tagged data-i18n. Elements keep
// their original English as the markup default, so the page is readable even
// if this script fails to load.
function applyLanguage(lang) {
  const code = I18N[lang] ? lang : 'en';
  document.documentElement.setAttribute('lang', code);
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    // Leave anything an admin explicitly reworded via the CMS. Overwriting
    // it would silently undo a deliberate editorial change every time the
    // page loaded, which is worse than that one heading staying in the
    // language it was written in.
    if (el.hasAttribute('data-cms-applied')) return;
    const key = el.getAttribute('data-i18n');
    // Untranslated key: leave the English already in the markup. See
    // hasTranslation() above for why this is not merely a nicety.
    if (!hasTranslation(key, code)) return;
    const value = t(key, code);
    if (value) el.textContent = value;
  });
  document.querySelectorAll('[data-i18n-aria]').forEach((el) => {
    const key = el.getAttribute('data-i18n-aria');
    if (!hasTranslation(key, code)) return;
    const value = t(key, code);
    if (value) el.setAttribute('aria-label', value);
  });
  const picker = document.getElementById('langPicker');
  if (picker && picker.value !== code) picker.value = code;
}

function setLanguage(lang) {
  try { localStorage.setItem(I18N_KEY, lang); } catch (e) { /* ignore */ }
  applyLanguage(lang);
}

document.addEventListener('DOMContentLoaded', () => {
  const picker = document.getElementById('langPicker');
  if (picker) {
    picker.innerHTML = Object.keys(I18N)
      .map((code) => `<option value="${code}">${I18N[code]._label}</option>`)
      .join('');
    picker.addEventListener('change', () => setLanguage(picker.value));
  }
  applyLanguage(currentLang());
});
